import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'config.dart';
import 'screens/home_screen.dart';
import 'screens/generator_screen.dart';
import 'screens/search_screen.dart';
import 'screens/more_screen.dart';
import 'widgets/ad_banner.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await MobileAds.instance.initialize();
  runApp(const PromptMaharajaApp());
}
class PromptMaharajaApp extends StatelessWidget {
  const PromptMaharajaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Prompt Maharaja',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: AppColors.bg,
        appBarTheme: const AppBarTheme(backgroundColor: AppColors.bg, foregroundColor: AppColors.gold,
            titleTextStyle: TextStyle(color: AppColors.gold, fontSize: 18, fontWeight: FontWeight.bold, letterSpacing: 2)),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Color(0xFF141414), selectedItemColor: AppColors.gold, unselectedItemColor: Colors.white38),
      ),
      home: const MainNav(),
    );
  }
}
class MainNav extends StatefulWidget {
  const MainNav({super.key});
  @override
  State<MainNav> createState() => _MainNavState();
}
class _MainNavState extends State<MainNav> {
  int _i = 0;
  final _pages = const [HomeScreen(), GeneratorScreen(), SearchScreen(), MoreScreen()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: [Expanded(child: IndexedStack(index: _i, children: _pages)), const AdBanner()]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _i, onTap: (v) => setState(() => _i = v), type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.auto_awesome), label: 'Generate'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.menu), label: 'More'),
        ],
      ),
    );
  }
}
