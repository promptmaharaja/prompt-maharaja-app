# Prompt Maharaja V5 Final - Proper (36 files, original names)

## 7 Fixes
1. Splash: single logo (assets/Splash.logo.png), delay 1800ms
2. Homepage (Home.dart): 9 categories from Prompts.dart
3. Royal Portraits: category id matched in Prompts.dart
4. Trending: maxLines=2, ellipsize=end
5. More.dart: sign-up button hook + Legal.dart black-gold (#000000 + #D4AF37)
6. Generate.dart: Pollinations https://image.pollinations.ai/prompt/$enc?width=$w&height=$h&seed=$seed&nologo=true&model=z-image-turbo
7. Latest: demo card style

## Build
flutter pub get
flutter build apk --release

## Files: 36 with original names
