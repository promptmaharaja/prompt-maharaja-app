
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'theme.dart';
import 'screens/splash.dart';
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const MaharajaApp());
}
class MaharajaApp extends StatelessWidget {
  const MaharajaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Prompt Maharaja', debugShowCheckedModeBanner: false,
      theme: Pm.theme(), home: const SplashScreen());
  }
}
