# Prompt Maharaja FINAL - All Fixed

- Firebase linked (Main.dart async + Firebase.initializeApp)
- google-services.json project_id: prompt-maharaja
- Splash/Opening: 1800ms single logo, no stuck
- Home: 9 categories
- Royal Portraits: verified
- Trending: maxLines=2
- Legal: black #000000 + gold #D4AF37 demo style
- Generate: Pollinations nologo=true model=z-image-turbo
- Copy buttons: in Prompt_detail.dart
- Search: Search.dart
- Admin: lib/data/Admin.dart (Firestore prompts upload) + admin_panel_demo.html
- AdMob: google_mobile_ads init in Main.dart

Build:
flutter pub get
flutter build apk --release
