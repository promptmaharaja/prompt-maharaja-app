
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import '../data/favs.dart';
class PromptDetail extends StatefulWidget {
  final PmPrompt prompt;
  const PromptDetail({super.key, required this.prompt});
  @override
  State<PromptDetail> createState() => _PromptDetailState();
}
class _PromptDetailState extends State<PromptDetail> {
  bool fav = false;
  @override
  void initState() { super.initState(); Favs.has(widget.prompt.id).then((v) { if (mounted) setState(() => fav = v); }); }
  @override
  Widget build(BuildContext context) {
    final p = widget.prompt;
    final catName = Store.catName(p.cat);
    return Scaffold(backgroundColor: Pm.bg,
      appBar: AppBar(title: Text(p.title, style: Pm.serif(18)),
        actions: [IconButton(
          icon: Icon(fav ? Icons.favorite : Icons.favorite_outline, color: Pm.gold),
          onPressed: () async { await Favs.toggle(p.id); setState(() => fav = !fav); })]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(height: 180,
          decoration: BoxDecoration(color: Pm.gold.withOpacity(0.08), borderRadius: BorderRadius.circular(20), border: Border.all(color: Pm.line)),
          child: const Center(child: Icon(Icons.image_outlined, color: Pm.gold, size: 64))),
        const SizedBox(height: 16),
        Row(children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(border: Border.all(color: Pm.gold), borderRadius: BorderRadius.circular(20)),
            child: Text(catName, style: const TextStyle(color: Pm.gold, fontSize: 12))),
          if (p.isNew) ...[const SizedBox(width: 8),
            Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(color: Pm.gold, borderRadius: BorderRadius.circular(20)),
              child: const Text('NEW', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Colors.black)))],
        ]),
        const SizedBox(height: 14),
        Text(p.title, style: Pm.serif(24).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        Pm.cardBox(Text(p.text, style: Pm.body)),
          if (p.neg.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text('Negative prompt', style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600, color: Pm.gold)),
            const SizedBox(height: 6),
            Pm.cardBox(Text(p.neg, style: Pm.small)),
          ],
        const SizedBox(height: 12),
        Wrap(spacing: 8, children: p.tags.map((t) => Chip(
          label: Text(t, style: const TextStyle(fontSize: 12)),
          backgroundColor: Pm.card, side: const BorderSide(color: Pm.line))).toList()),
        const SizedBox(height: 20),
        Pm.goldBtn('Copy Prompt', () {
          Clipboard.setData(ClipboardData(text: p.text));
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Prompt copied!'), backgroundColor: Pm.gold, behavior: SnackBarBehavior.floating));
        }),
      ]));
  }
}
