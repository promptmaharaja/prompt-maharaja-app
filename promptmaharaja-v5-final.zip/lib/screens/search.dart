
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import 'prompt_detail.dart';
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}
class _SearchScreenState extends State<SearchScreen> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final ql = q.toLowerCase();
    final res = q.isEmpty ? <PmPrompt>[] : Store.prompts.where((p) =>
      p.title.toLowerCase().contains(ql) || p.text.toLowerCase().contains(ql) ||
      p.tags.any((t) => t.toLowerCase().contains(ql))).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 8),
          Text('Search', style: Pm.serif(26).copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          TextField(onChanged: (v) => setState(() => q = v), style: const TextStyle(color: Pm.cream),
            decoration: InputDecoration(hintText: 'warrior, neon, logo, anime...', hintStyle: Pm.small,
              prefixIcon: const Icon(Icons.search, color: Pm.muted),
              filled: true, fillColor: Pm.card,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: const BorderSide(color: Pm.line)))),
        ])),
      Expanded(child: q.isEmpty
        ? const Center(child: Text('Type to search the treasury', style: Pm.small))
        : res.isEmpty
          ? const Center(child: Text('No prompts found', style: Pm.small))
          : ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 18),
              itemCount: res.length,
              itemBuilder: (_, i) {
                final p = res[i];
                return GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetail(prompt: p))),
                  child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
                    child: Text(p.title, style: Pm.serif(15).copyWith(fontWeight: FontWeight.w600))));
              })),
    ]);
  }
}
