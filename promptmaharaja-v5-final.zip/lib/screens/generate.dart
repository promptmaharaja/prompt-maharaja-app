
import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';
class GenerateScreen extends StatefulWidget {
  const GenerateScreen({super.key});
  @override
  State<GenerateScreen> createState() => _GenerateScreenState();
}
class _GenerateScreenState extends State<GenerateScreen> {
  final ctrl = TextEditingController(text: 'A royal Bengal tiger wearing a golden crown, sitting on a marble throne');
  String style = 'Default';
  String size = 'Square';
  String? imgUrl;
  final styles = ['Default', 'Maharaja Royal', 'Cinematic', 'Anime', 'Photoreal', 'Digital Art', 'Poster'];
  final sizes = {'Square': [1024, 1024], 'Portrait': [768, 1024], 'Landscape': [1024, 768]};
  final surprises = [
    'A majestic peacock with golden feathers in a royal palace garden at sunset',
    'A warrior queen on horseback, cinematic lighting, epic battlefield background',
    'A neon-lit cyberpunk Mumbai street at night, rain reflections, anime style',
    'An ancient temple floating among clouds, divine golden light rays',
  ];
  void generate() {
    if (ctrl.text.trim().isEmpty) return;
    var prompt = ctrl.text.trim();
    if (style != 'Default') prompt = '$prompt, $style style';
    final w = sizes[size]![0], h = sizes[size]![1];
    final seed = Random().nextInt(999999);
    final enc = Uri.encodeComponent(prompt);
    setState(() => imgUrl = 'https://image.pollinations.ai/prompt/$enc?width=$w&height=$h&seed=$seed&nologo=true&model=z-image-turbo');
  }
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      const Text('FREE AI STUDIO', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12)),
      const SizedBox(height: 6),
      Text('Generate Image', style: Pm.serif(30).copyWith(fontWeight: FontWeight.w700)),
      const SizedBox(height: 6),
      const Text('Describe your dream — the Maharaja paints it for free.', style: Pm.small),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Your prompt', style: Pm.serif(17).copyWith(fontWeight: FontWeight.w600)),
        GestureDetector(
          onTap: () => setState(() => ctrl.text = (surprises..shuffle()).first),
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(border: Border.all(color: Pm.gold), borderRadius: BorderRadius.circular(25)),
            child: const Row(children: [Icon(Icons.casino_outlined, color: Pm.gold, size: 16), SizedBox(width: 6),
              Text('Surprise me', style: TextStyle(color: Pm.gold, fontWeight: FontWeight.w600))])),
      ]),
      const SizedBox(height: 10),
      TextField(controller: ctrl, maxLines: 4, style: Pm.body,
        decoration: InputDecoration(filled: true, fillColor: Pm.card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: Pm.line)),
          hintText: 'Describe your image...', hintStyle: Pm.small)),
      const SizedBox(height: 16),
      Text('Style', style: Pm.serif(17).copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 10, children: styles.map((s) {
        final on = s == style;
        return GestureDetector(
          onTap: () => setState(() => style = s),
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            decoration: BoxDecoration(color: on ? Pm.gold : Pm.card, borderRadius: BorderRadius.circular(25),
              border: Border.all(color: on ? Pm.gold : Pm.line)),
            child: Text(s, style: TextStyle(color: on ? Colors.black : Pm.cream, fontWeight: FontWeight.w600))));
      }).toList()),
      const SizedBox(height: 6),
      const Text('✨ No style mixing — your exact prompt will be used as-is', style: Pm.small),
      const SizedBox(height: 16),
      Text('Size', style: Pm.serif(17).copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Row(children: sizes.keys.map((s) {
        final on = s == size;
        return Expanded(child: GestureDetector(
          onTap: () => setState(() => size = s),
          child: Container(margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(color: on ? Pm.gold : Pm.card, borderRadius: BorderRadius.circular(18),
              border: Border.all(color: on ? Pm.gold : Pm.line)),
            child: Column(children: [
              Text(s, style: TextStyle(color: on ? Colors.black : Pm.cream, fontWeight: FontWeight.w700)),
              Text('${sizes[s]![0]} x ${sizes[s]![1]}', style: TextStyle(color: on ? Colors.black54 : Pm.muted, fontSize: 12)),
            ]))));
      }).toList()),
      const SizedBox(height: 20),
      Pm.goldBtn('GENERATE IMAGE', generate),
      const SizedBox(height: 20),
      if (imgUrl != null)
        ClipRRect(borderRadius: BorderRadius.circular(20),
          child: Image.network(imgUrl!,
            loadingBuilder: (_, child, p) => p == null ? child :
              Container(height: 300, alignment: Alignment.center, child: const CircularProgressIndicator(color: Pm.gold)),
            errorBuilder: (_, __, ___) => Pm.cardBox(const Text('Could not generate. Check internet and try again.', style: Pm.small)))),
    ]);
  }
}
