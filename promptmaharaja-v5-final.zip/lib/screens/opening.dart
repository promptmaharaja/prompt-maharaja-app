
import 'package:flutter/material.dart';
import '../theme.dart';
import '../shell.dart';
class OpeningScreen extends StatefulWidget {
  const OpeningScreen({super.key});
  @override
  State<OpeningScreen> createState() => _OpeningScreenState();
}
class _OpeningScreenState extends State<OpeningScreen> with SingleTickerProviderStateMixin {
  late AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..forward();
    c.addStatusListener((s) {
      if (s == AnimationStatus.completed && mounted)
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Shell()));
    });
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black,
      body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        ClipOval(child: Image.asset('assets/logo.png', width: 110, height: 110, fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => const Icon(Icons.workspace_premium, size: 80, color: Pm.gold))),
        const SizedBox(height: 28),
        Text('PROMPT MAHARAJA', style: Pm.serif(28, c: Pm.gold).copyWith(letterSpacing: 3, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        const Text('AI PROMPTS COLLECTION', style: TextStyle(color: Pm.gold, letterSpacing: 4, fontSize: 12)),
        const SizedBox(height: 40),
        const Text('OPENING TREASURY', style: TextStyle(color: Pm.muted, letterSpacing: 3, fontSize: 12)),
        const SizedBox(height: 12),
        SizedBox(width: 220, child: AnimatedBuilder(animation: c,
          builder: (_, __) => LinearProgressIndicator(value: c.value, backgroundColor: Pm.line, color: Pm.gold, minHeight: 4))),
      ])));
  }
}
