
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import '../shell.dart';
import 'category_detail.dart';
import 'prompt_detail.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  Widget _card(BuildContext context, PmPrompt p) {
    final cat = Store.cats.firstWhere((c) => c.id == p.cat);
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetail(prompt: p))),
      child: Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
        child: Row(children: [
          Container(width: 52, height: 52,
            decoration: BoxDecoration(color: Pm.gold.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.image_outlined, color: Pm.gold)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(p.title, style: Pm.serif(15).copyWith(fontWeight: FontWeight.w600))),
              if (p.isNew) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: Pm.gold, borderRadius: BorderRadius.circular(10)),
                child: const Text('NEW', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.black))),
            ]),
            const SizedBox(height: 4),
            Text(cat.name, style: Pm.small),
          ])),
        ])));
  }
  @override
  Widget build(BuildContext context) {
    final latest = Store.prompts.where((p) => p.isNew).toList();
    final rest = Store.prompts.where((p) => !p.isNew).toList();
    final show = [...latest, ...rest].take(6).toList();
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      Text('Hello, Maharaja', style: Pm.serif(26).copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 4),
      const Text('What shall we create today?', style: Pm.small),
      const SizedBox(height: 16),
      GestureDetector(
        onTap: () => context.findAncestorStateOfType<ShellState>()?.go(2),
        child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(30), border: Border.all(color: Pm.line)),
          child: const Row(children: [Icon(Icons.search, color: Pm.muted, size: 20), SizedBox(width: 8),
            Text('Search prompts...', style: Pm.small)]))),
      const SizedBox(height: 22),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Categories', style: Pm.serif(19).copyWith(fontWeight: FontWeight.w600)),
        GestureDetector(
          onTap: () => context.findAncestorStateOfType<ShellState>()?.go(1),
          child: const Text('See all', style: TextStyle(color: Pm.gold, fontSize: 13))),
      ]),
      const SizedBox(height: 12),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.15),
        itemCount: 4,
        itemBuilder: (_, i) {
          final cat = Store.cats[i];
          final n = Store.prompts.where((p) => p.cat == cat.id).length;
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryDetail(cat: cat))),
            child: Pm.cardBox(Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.auto_awesome, color: Pm.gold, size: 26),
              const SizedBox(height: 10),
              Text(cat.name, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text('$n prompts', style: Pm.small),
            ])));
        }),
      const SizedBox(height: 22),
      Text('Latest Prompts', style: Pm.serif(19).copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 12),
      ...show.map((p) => _card(context, p)),
    ]);
  }
}
