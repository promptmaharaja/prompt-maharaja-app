
import 'package:flutter/material.dart';
class Pm {
  static const bg = Color(0xFF0D0D0D);
  static const card = Color(0xFF161616);
  static const gold = Color(0xFFD4AF37);
  static const cream = Color(0xFFF3ECD9);
  static const muted = Color(0xFF9C8F74);
  static const line = Color(0xFF2A2418);
  static TextStyle hserif(double s, {Color c = cream, double ls = 0}) =>
      TextStyle(fontSize: s, color: c, letterSpacing: ls, fontWeight: FontWeight.w700, fontFamily: 'serif', fontFamilyFallback: const ['Georgia', 'serif']);
  static TextStyle serif(double s, {Color c = cream}) =>
      TextStyle(fontSize: s, color: c, fontFamily: 'serif', fontFamilyFallback: const ['Georgia', 'serif']);
  static const body = TextStyle(fontSize: 15, color: cream, height: 1.5);
  static const small = TextStyle(fontSize: 13, color: muted);
  static ThemeData theme() => ThemeData.dark().copyWith(
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(primary: gold, surface: card),
        appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0));
  static Widget goldBtn(String t, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(color: gold, borderRadius: BorderRadius.circular(40)),
          alignment: Alignment.center,
          child: Text(t, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w800, fontSize: 16))));
  static Widget cardBox(Widget child) => Container(padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(20), border: Border.all(color: line)),
        child: child);
}
