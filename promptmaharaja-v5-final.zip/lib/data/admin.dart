import 'package:cloud_firestore/cloud_firestore.dart';

/// Admin panel - direct prompts upload to Firestore
/// Collection: prompts
/// Fields: title, prompt, neg, categoryId
class AdminService {
  static final _db = FirebaseFirestore.instance;

  static Future<void> uploadPrompt({
    required String title,
    required String prompt,
    required String categoryId,
    String neg = '',
  }) async {
    await _db.collection('prompts').add({
      'title': title,
      'prompt': prompt,
      'neg': neg,
      'categoryId': categoryId,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  static Stream<QuerySnapshot> promptsStream() {
    return _db.collection('prompts').orderBy('createdAt', descending: true).snapshots();
  }
}
