import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'prompts.dart';

class Store {
  static List<PmCategory> cats = kCategories;
  static List<PmPrompt> prompts = kPrompts;
  static bool firebaseOk = false;

  static Future<void> init() async {
    try {
      await Firebase.initializeApp();
      final snap = await FirebaseFirestore.instance
          .collection('prompts')
          .get()
          .timeout(const Duration(seconds: 12));
      final fbIds = <String>{};
      final fb = <PmPrompt>[];
      for (final d in snap.docs) {
        final m = d.data();
        final title = (m['title'] ?? '').toString();
        final text = (m['prompt'] ?? '').toString();
        if (title.isEmpty || text.isEmpty) continue;
        fbIds.add(d.id);
        fb.add(PmPrompt(
          d.id,
          title,
          _normCat((m['cat'] ?? '').toString()),
          text,
          ((m['tags'] as List?) ?? []).map((e) => e.toString()).toList(),
          isNew: m['isNew'] == true,
          neg: (m['neg'] ?? '').toString(),
        ));
      }
      if (fb.isNotEmpty) {
        firebaseOk = true;
        prompts = [...fb, ...kPrompts.where((p) => !fbIds.contains(p.id))];
      }
    } catch (_) {
      // offline ya error -> bundled 29 prompts dikhenge
    }
  }

  static String _normCat(String c) {
    const map = {
      'royal portraits': 'royal-portraits',
      'cinematic': 'cinematic',
      'anime world': 'anime-world',
      'festival vibes': 'festival-vibes',
      'logo lab': 'logo-lab',
      'poster house': 'poster-house',
      'product ads': 'product-ads',
      'art styles': 'art-styles',
      'trending prompts': 'trending',
    };
    final k = c.trim().toLowerCase();
    return map[k] ?? (c.trim().isEmpty ? 'trending' : c.trim());
  }

  static String catName(String id) {
    try {
      return cats.firstWhere((c) => c.id == id).name;
    } catch (_) {
      return id;
    }
  }

  static int countFor(String id) => prompts.where((p) => p.cat == id).length;
}
