// 29 prompts, 9 categories - native app data

class PmCategory {
  final String id, name, blurb;
  const PmCategory(this.id, this.name, this.blurb);
}

class PmPrompt {
  final String id, title, cat, text, neg;
  final bool isNew;
  final List<String> tags;
  const PmPrompt(this.id, this.title, this.cat, this.text, this.tags, {this.isNew = false, this.neg = '''});
}

const kCategories = <PmCategory>[
  PmCategory("royal-portraits", "Royal Portraits", "Majestic faces, royal characters & stunning personalities."),
  PmCategory("cinematic", "Cinematic", "Film-still drama, moody light & unforgettable frames."),
  PmCategory("anime-world", "Anime World", "Vibrant anime worlds, warriors & dreamy skies."),
  PmCategory("festival-vibes", "Festival Vibes", "Diwali diyas, Holi colours & grand celebrations."),
  PmCategory("logo-lab", "Logo Lab", "Bold brand marks, emblems & iconic identities."),
  PmCategory("poster-house", "Poster House", "Epic poster art, wall-worthy frames & bold visuals."),
  PmCategory("product-ads", "Product Ads", "Stunning product shots & ads that truly sell."),
  PmCategory("art-styles", "Art Styles", "Oil paintings, watercolours & timeless art styles."),
  PmCategory("trending", "Trending Prompts", "Viral couple portraits, 90s looks & butterfly dreams."),
];

const kPrompts = <PmPrompt>[
  PmPrompt("p01", "Golden Turban Maharaja", "royal-portraits", "Regal Indian maharaja portrait, golden silk turban with jeweled sarpech, embroidered black sherwani with gold zardozi, dramatic rim lighting, dark palace hall background, ultra-detailed skin texture, photorealistic, 85mm portrait, 8k", [""portrait"", ""royal"", ""photorealistic""]),
  PmPrompt("p02", "Neon Samurai Night", "anime-world", "Anime samurai standing on a neon-lit Tokyo rooftop at night, katana glowing electric blue, rain droplets frozen mid-air, vibrant cel shading, dynamic low-angle composition, ultra detailed key visual", [""anime"", ""cyberpunk"", ""night""]),
  PmPrompt("p03", "Desert Palace Mirage", "poster-house", "Floating golden palace above desert dunes at sunset, waterfalls pouring from sky islands, royal elephants with jeweled howdahs walking on clouds, epic fantasy matte painting, volumetric god rays", [""fantasy"", ""palace"", ""epic""]),
  PmPrompt("p04", "Diwali Diya Glow", "festival-vibes", "Close-up of ornate brass diyas floating on dark water with marigold petals, bokeh of fireworks in the night sky, warm golden glow on ripples, macro photography, festive magic, ultra detailed", [""diwali"", ""festival"", ""macro""]),
  PmPrompt("p05", "Monsoon Mumbai Street", "cinematic", "Rain-soaked Mumbai street at blue hour, yellow taxi reflections on wet asphalt, cinematic anamorphic lens flare, lone figure with umbrella, moody film still, teal and orange grade", [""cinematic"", ""rain"", ""street""]),
  PmPrompt("p06", "Himalayan Sadhu Dawn", "royal-portraits", "Weathered sadhu portrait at Himalayan dawn, ash-covered face, piercing calm eyes, rudraksha beads, misty snow peaks behind, first light on skin, National Geographic style, photorealistic", [""portrait"", ""spiritual"", ""dawn""]),
  PmPrompt("p07", "Cyberpunk Rickshaw Chase", "cinematic", "Futuristic auto-rickshaw racing through a neon Old Delhi alley, holographic shop signs, motion blur on wheels, cinematic chase frame, blade-runner mood, rain reflections", [""cinematic"", ""cyberpunk"", ""action""]),
  PmPrompt("p08", "Rose Garden Proposal", "cinematic", "Royal couple in a Mughal rose garden at golden hour, petals swirling in the wind, marble pavilion behind, dreamy romantic glow, cinematic wedding photography, soft lens flare", [""love"", ""wedding"", ""golden hour""]),
  PmPrompt("p09", "Startup Office Hustle", "product-ads", "Modern Indian startup office at night, glass walls, young team around glowing screens, city lights bokeh outside, motivational corporate photography, wide angle, energetic mood", [""business"", ""office"", ""night""]),
  PmPrompt("p10", "Peacock Throne Room", "poster-house", "Empty peacock throne in a vast marble hall, sunbeams streaming through jharokha windows, dust motes dancing in light, peacocks perched on carved pillars, epic scale, fantasy realism", [""fantasy"", ""throne"", ""royal""]),
  PmPrompt("p11", "Cherry Blossom Warrior", "anime-world", "Anime warrior girl with flowing scarf standing under a storm of cherry blossoms, petals and sparks swirling, dramatic low angle, vivid colours, Makoto Shinkai style luminous sky", [""anime"", ""warrior"", ""blossoms""]),
  PmPrompt("p12", "Tiger in the Ghats", "poster-house", "Bengal tiger emerging from morning mist in a Western Ghats forest, sun rays cutting through the canopy, wildlife photography, 400mm telephoto, razor-sharp amber eyes", [""nature"", ""wildlife"", ""tiger""]),
  PmPrompt("p13", "Holi Colour Burst", "festival-vibes", "Joyful friends mid-jump throwing clouds of gulal, explosion of pink yellow and blue powder frozen in air, slow-motion freeze, festival euphoria, ultra vibrant, dynamic composition", [""holi"", ""festival"", ""colours""]),
  PmPrompt("p14", "Maharani Jewel Portrait", "royal-portraits", "Elegant maharani portrait, polki diamond choker, deep red Banarasi silk, kohl-lined confident eyes, soft window light, renaissance painting meets modern photography, timeless grace", [""portrait"", ""royal"", ""jewellery""]),
  PmPrompt("p15", "Space Dosa Diner", "product-ads", "Retro-futuristic South Indian diner on a space station, friendly robot serving crispy dosa on a banana leaf, Earth glowing through the dome window, whimsical sci-fi illustration, warm humour", [""fantasy"", ""sci-fi"", ""whimsical""]),
  PmPrompt("p16", "Kerala Backwater Calm", "poster-house", "Traditional kettuvallam houseboat gliding through Kerala backwaters at sunrise, palm reflections on still water, fisherman casting a net in the distance, serene minimalism, pastel tones", [""nature"", ""kerala"", ""serene""]),
  PmPrompt("p17", "CEO Corner Office", "poster-house", "Confident Indian CEO silhouette in a glass corner office overlooking the Mumbai skyline at dusk, power pose, cinematic low-key lighting, magazine cover style, ambition in every pixel", [""business"", ""success"", ""portrait""]),
  PmPrompt("p18", "Qawwali Night", "cinematic", "Sufi qawwali performers under a single spotlight in an old haveli courtyard, harmonium and tabla players, swirling incense smoke, intimate documentary frame, chiaroscuro lighting", [""cinematic"", ""music"", ""heritage""]),
  PmPrompt("p19", "First Rain Romance", "cinematic", "Young couple sharing one umbrella in the first monsoon rain, Marine Drive promenade blurred behind, cinematic teal grade, stolen laughing moment, 50mm f/1.4 creamy bokeh", [""love"", ""monsoon"", ""cinematic""]),
  PmPrompt("p20", "Dragon Over Jaipur", "poster-house", "Golden dragon soaring above Hawa Mahal at sunrise, the pink city waking below, colourful kites in the sky, epic fantasy poster art, dramatic clouds, sense of wonder", [""fantasy"", ""dragon"", ""jaipur""]),
  PmPrompt("p21", "Bride in Red Lehenga", "royal-portraits", "Indian bridal portrait, red embroidered lehenga, kaleere bangles frozen mid-motion, joyful candid laugh, marigold flower backdrop, candid wedding photography, warm golden light", [""portrait"", ""wedding"", ""bridal""]),
  PmPrompt("p22", "Mecha Ganesh Guardian", "anime-world", "Colossal mecha-Ganesha deity protecting futuristic Mumbai, glowing circuits along the trunk, tiny devotees holding diyas below, anime key visual, awe and devotion, dramatic scale", [""anime"", ""deity"", ""epic""]),
  PmPrompt("p23", "Alpine Lake Mirror", "poster-house", "Mirror-still alpine lake at dawn, snow peaks doubled in perfect reflection, lone pine on a rocky islet, long exposure silky water, tranquil minimalism, cool blue palette", [""nature"", ""lake"", ""minimal""]),
  PmPrompt("p24", "Chai Stall Stories", "cinematic", "Old chaiwala pouring cutting chai at a dawn street stall, steam curling in the first light, regulars silhouetted on benches, nostalgic film grain, slice-of-life masterpiece", [""cinematic"", ""street"", ""nostalgia""]),
  PmPrompt("p25", "Royal Oil Painting Portrait", "art-styles", "Classic oil painting portrait of a regal Indian king, visible brushstrokes, rich impasto texture, dramatic chiaroscuro lighting, dark ornate palace background, museum-quality baroque style, aged canvas feel", [""oil painting"", ""royal"", ""classic""]),
  PmPrompt("p26", "Watercolor Monsoon Muse", "art-styles", "Soft watercolor portrait of a young woman with flowing hair, delicate washes of pink and teal, monsoon rain droplets melting on paper, loose expressive strokes, handmade paper texture, dreamy ethereal style", [""watercolor"", ""portrait"", ""dreamy""]),
  PmPrompt("p27", "Couple Under the Stars", "trending", "Romantic couple portrait under a starry Milky Way sky, fairy lights glowing behind them, warm cinematic light on their faces, cozy candid moment, dreamy bokeh, viral Instagram aesthetic", [""couple"", ""romantic"", ""trending""]),
  PmPrompt("p28", "90s Butterfly Dream", "trending", "90s retro photoshoot style, girl with butterfly hair clips, film grain, vintage flash photography look, colourful butterfly wings shimmering behind, nostalgic 90s magazine vibe", [""90s"", ""butterfly"", ""retro""]),
  PmPrompt("p29", "Golden Lion Emblem", "logo-lab", "Luxury lion head emblem logo, gold foil on deep black, sharp geometric lines, premium brand identity, minimal vector style, symmetrical royal crest design", [""logo"", ""emblem"", ""luxury""]),
];