
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'theme.dart';
import 'screens/splash.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  MobileAds.instance.initialize();
  runApp(const MaharajaApp());
}
class MaharajaApp extends StatelessWidget {
  const MaharajaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Prompt Maharaja', debugShowCheckedModeBanner: false,
      theme: Pm.theme(), home: const SplashScreen());
  }
}
