
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'theme.dart';
import 'screens/home.dart';
import 'screens/categories.dart';
import 'screens/search.dart';
import 'screens/favorites.dart';
import 'screens/generate.dart';
import 'screens/more.dart';
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => ShellState();
}
class ShellState extends State<Shell> {
  int idx = 0;
  BannerAd? banner;
  bool bannerOk = false;
  static const _tabs = ['Home', 'Categories', 'Search', 'Favorites', 'Generate', 'More'];
  static const _icons = [Icons.home_outlined, Icons.grid_view_outlined, Icons.search_outlined, Icons.favorite_outline, Icons.auto_awesome_outlined, Icons.more_horiz];
  @override
  void initState() {
    super.initState();
    banner = BannerAd(adUnitId: 'ca-app-pub-3940256099942544/6300978111', size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => bannerOk = true),
        onAdFailedToLoad: (_, __) => setState(() => bannerOk = false)))..load();
  }
  @override
  void dispose() { banner?.dispose(); super.dispose(); }
  void go(int i) => setState(() => idx = i);
  @override
  Widget build(BuildContext context) {
    final pages = [const HomeScreen(), const CategoriesScreen(), const SearchScreen(), const FavoritesScreen(), const GenerateScreen(), const MoreScreen()];
    return Scaffold(backgroundColor: Pm.bg,
      body: SafeArea(child: Column(children: [
        Expanded(child: IndexedStack(index: idx, children: pages)),
        Container(decoration: const BoxDecoration(border: Border(top: BorderSide(color: Pm.line))),
          child: BottomNavigationBar(currentIndex: idx, onTap: go, type: BottomNavigationBarType.fixed,
            backgroundColor: Pm.bg, selectedItemColor: Pm.gold, unselectedItemColor: Pm.muted,
            selectedFontSize: 11, unselectedFontSize: 11,
            items: List.generate(6, (i) => BottomNavigationBarItem(icon: Icon(_icons[i]), label: _tabs[i])))),
        if (bannerOk && banner != null)
          SizedBox(width: banner!.size.width.toDouble(), height: banner!.size.height.toDouble(), child: AdWidget(ad: banner!)),
      ])));
  }
}
