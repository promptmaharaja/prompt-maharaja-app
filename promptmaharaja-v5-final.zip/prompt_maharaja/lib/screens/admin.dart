
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _col = FirebaseFirestore.instance.collection('prompts');
  String _search = '';

  Future<void> _deletePrompt(String id, String title) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      backgroundColor: Pm.card,
      title: Text('Delete?', style: Pm.serif(18).copyWith(color: Pm.gold)),
      content: Text('"$title" delete karna hai?', style: const TextStyle(color: Pm.cream)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel', style: TextStyle(color: Pm.muted))),
        TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete', style: TextStyle(color: Colors.red))),
      ],
    ));
    if (ok == true) {
      await _col.doc(id).delete();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Deleted'), backgroundColor: Pm.card));
    }
  }

  void _openEditor({DocumentSnapshot? doc}) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PromptEditor(doc: doc)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pm.bg,
      appBar: AppBar(
        backgroundColor: Pm.bg, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Pm.gold), onPressed: () => Navigator.pop(context)),
        title: Text('Admin Panel', style: Pm.serif(22).copyWith(color: Pm.gold, fontWeight: FontWeight.w700)),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Pm.gold,
        onPressed: () => _openEditor(),
        child: const Icon(Icons.add, color: Colors.black),
      ),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(16), child: TextField(
          style: const TextStyle(color: Pm.cream),
          decoration: InputDecoration(
            hintText: 'Search prompts...', hintStyle: const TextStyle(color: Pm.muted),
            prefixIcon: const Icon(Icons.search, color: Pm.gold),
            filled: true, fillColor: Pm.card,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
          ),
          onChanged: (v) => setState(() => _search = v.toLowerCase()),
        )),
        Expanded(child: StreamBuilder<QuerySnapshot>(
          stream: _col.snapshots(),
          builder: (c, snap) {
            if (snap.hasError) return const Center(child: Text('Error loading', style: TextStyle(color: Colors.red)));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: Pm.gold));
            var docs = snap.data!.docs;
            if (_search.isNotEmpty) {
              docs = docs.where((d) {
                final m = d.data() as Map<String, dynamic>;
                return (m['title'] ?? '').toString().toLowerCase().contains(_search);
              }).toList();
            }
            if (docs.isEmpty) return const Center(child: Text('No prompts found', style: TextStyle(color: Pm.muted)));
            return ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: docs.length,
              itemBuilder: (c, i) {
                final d = docs[i];
                final m = d.data() as Map<String, dynamic>;
                final title = (m['title'] ?? '').toString();
                final cat = (m['cat'] ?? '').toString();
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
                  child: ListTile(
                    title: Text(title, style: const TextStyle(color: Pm.cream, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(Store.catName(cat), style: const TextStyle(color: Pm.muted, fontSize: 12)),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.edit, color: Pm.gold, size: 20), onPressed: () => _openEditor(doc: d)),
                      IconButton(icon: const Icon(Icons.delete, color: Colors.red, size: 20), onPressed: () => _deletePrompt(d.id, title)),
                    ]),
                  ),
                );
              },
            );
          },
        )),
      ]),
    );
  }
}

class PromptEditor extends StatefulWidget {
  final DocumentSnapshot? doc;
  const PromptEditor({super.key, this.doc});
  @override
  State<PromptEditor> createState() => _PromptEditorState();
}

class _PromptEditorState extends State<PromptEditor> {
  final _col = FirebaseFirestore.instance.collection('prompts');
  late TextEditingController _title, _text, _neg, _tags;
  late String _cat;
  bool _isNew = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final m = widget.doc?.data() as Map<String, dynamic>?;
    _title = TextEditingController(text: (m?['title'] ?? '').toString());
    _text = TextEditingController(text: (m?['prompt'] ?? '').toString());
    _neg = TextEditingController(text: (m?['neg'] ?? '').toString());
    _tags = TextEditingController(text: ((m?['tags'] as List?) ?? []).join(', '));
    _cat = Store._normCat((m?['cat'] ?? '').toString());
    _isNew = m?['isNew'] == true;
  }

  @override
  void dispose() {
    _title.dispose(); _text.dispose(); _neg.dispose(); _tags.dispose();
    super.dispose();
  }

  Widget _field(String label, TextEditingController c, {int lines = 1}) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: Pm.gold, fontSize: 13, fontWeight: FontWeight.w600)),
      const SizedBox(height: 6),
      TextField(
        controller: c, maxLines: lines, style: const TextStyle(color: Pm.cream),
        decoration: InputDecoration(
          filled: true, fillColor: Pm.card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Pm.line)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Pm.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Pm.gold)),
        ),
      ),
    ]),
  );

  Future<void> _save() async {
    if (_title.text.trim().isEmpty || _text.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Title aur Prompt required hai'), backgroundColor: Pm.card));
      return;
    }
    setState(() => _saving = true);
    final data = {
      'title': _title.text.trim(),
      'prompt': _text.text.trim(),
      'cat': _cat,
      'neg': _neg.text.trim(),
      'tags': _tags.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
      'isNew': _isNew,
      'updatedAt': FieldValue.serverTimestamp(),
    };
    try {
      if (widget.doc != null) {
        await _col.doc(widget.doc!.id).update(data);
      } else {
        data['createdAt'] = FieldValue.serverTimestamp();
        await _col.add(data);
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved!'), backgroundColor: Pm.card));
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e'), backgroundColor: Pm.card));
    }
    if (mounted) setState(() => _saving = false);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.doc != null;
    return Scaffold(
      backgroundColor: Pm.bg,
      appBar: AppBar(
        backgroundColor: Pm.bg, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Pm.gold), onPressed: () => Navigator.pop(context)),
        title: Text(isEdit ? 'Edit Prompt' : 'New Prompt', style: Pm.serif(20).copyWith(color: Pm.gold)),
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        _field('Title', _title),
        Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Category', style: TextStyle(color: Pm.gold, fontSize: 13, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: Pm.line)),
            child: DropdownButtonHideUnderline(child: DropdownButton<String>(
              value: _cat, dropdownColor: Pm.card, isExpanded: true,
              style: const TextStyle(color: Pm.cream),
              items: kCategories.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name))).toList(),
              onChanged: (v) => setState(() => _cat = v!),
            )),
          ),
        ])),
        _field('Prompt Text', _text, lines: 6),
        _field('Negative Prompt', _neg, lines: 3),
        _field('Tags (comma separated)', _tags),
        SwitchListTile(
          title: const Text('Mark as New', style: TextStyle(color: Pm.cream)),
          value: _isNew, activeColor: Pm.gold,
          onChanged: (v) => setState(() => _isNew = v),
        ),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, height: 52, child: ElevatedButton(
          style: ElevatedButton.styleFrom(backgroundColor: Pm.gold, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          onPressed: _saving ? null : _save,
          child: _saving
            ? const CircularProgressIndicator(color: Colors.black)
            : Text(isEdit ? 'Update' : 'Add Prompt', style: const TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.w700)),
        )),
      ]),
    );
  }
}
