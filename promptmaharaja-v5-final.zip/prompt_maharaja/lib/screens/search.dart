
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/store.dart';
import 'prompt_detail.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctl = TextEditingController();
  String _q = '';
  final _popular = ['maharaja', 'diwali', 'anime', 'cinematic', 'portrait', 'couple'];

  @override
  void dispose() { _ctl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final q = _q.toLowerCase();
    final results = q.isEmpty ? [] : Store.prompts.where((p) =>
      p.title.toLowerCase().contains(q) || p.text.toLowerCase().contains(q)).toList();
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      const Text('SEARCH', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text('Search', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
      const SizedBox(height: 16),
      TextField(
        controller: _ctl, style: const TextStyle(color: Pm.cream),
        decoration: InputDecoration(
          hintText: 'Search royal prompts...', hintStyle: const TextStyle(color: Pm.muted),
          prefixIcon: const Icon(Icons.search, color: Pm.muted),
          filled: true, fillColor: Pm.card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Pm.gold)),
        ),
        onChanged: (v) => setState(() => _q = v),
      ),
      const SizedBox(height: 20),
      const Text('Popular right now', style: TextStyle(color: Pm.cream, fontSize: 15, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: _popular.map((t) => GestureDetector(
        onTap: () { _ctl.text = t; setState(() => _q = t); },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: Pm.line)),
          child: Text(t, style: const TextStyle(color: Pm.gold, fontSize: 13)),
        ),
      )).toList()),
      const SizedBox(height: 20),
      if (_q.isNotEmpty) ...[
        Text('${results.length} results', style: Pm.small),
        const SizedBox(height: 12),
        ...results.map((p) => GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetailPage(prompt: p))),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.title, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(Store.catName(p.cat), style: Pm.small),
            ]),
          ),
        )),
      ],
    ]);
  }
}
