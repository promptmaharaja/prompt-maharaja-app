import 'package:flutter/material.dart';
import '../theme.dart';
import 'legal.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  Widget _legalTile(BuildContext context, String title, String body) {
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LegalPage(title: title, body: body))),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600)),
            const Icon(Icons.chevron_right, color: Pm.gold, size: 20),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SizedBox(height: 8),
        const Text('ROYAL TREASURY', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text('More', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
          child: Column(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: Image.asset('assets/logo.png', width: 60, height: 60, fit: BoxFit.cover),
              ),
              const SizedBox(height: 12),
              Text('Sign in to sync your royal treasury across devices.', style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600), textAlign: TextAlign.center),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(side: BorderSide(color: Pm.line), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  onPressed: () {},
                  child: const Text('Sign In with Google', style: TextStyle(color: Pm.cream, fontSize: 15)),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('ABOUT', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        _legalTile(context, 'Privacy Policy', LegalTexts.privacy),
        _legalTile(context, 'Terms of Use', LegalTexts.terms),
        _legalTile(context, 'Licence', LegalTexts.licence),
        _legalTile(context, 'Refund Policy', LegalTexts.refund),
        _legalTile(context, 'About Us', LegalTexts.about),
        _legalTile(context, 'Contact Us', LegalTexts.contact),
        const SizedBox(height: 16),
        const Center(child: Text('v1.0.0', style: TextStyle(color: Pm.muted, fontSize: 12))),
        const SizedBox(height: 20),
      ],
    );
  }
}
