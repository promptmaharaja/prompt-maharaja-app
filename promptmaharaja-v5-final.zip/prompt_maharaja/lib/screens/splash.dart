
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/store.dart';
import 'opening.dart';
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await Store.init();
    if (mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const OpeningPage()));
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.black,
      body: Center(child: ClipOval(
        child: Image.asset('assets/logo.png', width: 200, height: 200, fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => const Icon(Icons.workspace_premium, size: 120, color: Pm.gold)))));
  }
}
