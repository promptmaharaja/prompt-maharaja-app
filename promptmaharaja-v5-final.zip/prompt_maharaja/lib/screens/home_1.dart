
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import '../shell.dart';
import 'category_detail.dart';
import 'prompt_detail.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget _catCard(BuildContext context, PmCategory cat, IconData icon) {
    final n = Store.prompts.where((p) => p.cat == cat.id).length;
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryDetailPage(cat: cat))),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: Pm.gold, size: 26),
          const SizedBox(height: 10),
          Text(cat.name, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('$n prompts', style: Pm.small),
        ]),
      ),
    );
  }

  Widget _promptCard(BuildContext context, PmPrompt p) {
    final catName = Store.catName(p.cat).toUpperCase();
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetailPage(prompt: p))),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line),
        ),
        child: Stack(children: [
          // Crown watermark
          Positioned(
            right: 0, top: 0,
            child: Opacity(opacity: 0.06, child: Icon(Icons.workspace_premium, size: 80, color: Pm.gold)),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: Pm.gold.withOpacity(0.15), borderRadius: BorderRadius.circular(6)),
                child: Text(catName, style: const TextStyle(color: Pm.gold, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
              ),
              const Spacer(),
              Icon(Icons.workspace_premium, color: Pm.gold.withOpacity(0.5), size: 20),
            ]),
            const SizedBox(height: 10),
            Text(p.title, style: Pm.serif(18).copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text('${p.text.length} CHARS', style: const TextStyle(color: Pm.muted, fontSize: 11, letterSpacing: 1)),
            const SizedBox(height: 8),
            Row(children: [
              const Text('View prompt', style: TextStyle(color: Pm.gold, fontSize: 14)),
              const SizedBox(width: 4),
              const Icon(Icons.arrow_forward, color: Pm.gold, size: 16),
            ]),
          ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final icons = {
      'royal-portraits': Icons.workspace_premium,
      'cinematic': Icons.movie,
      'anime-world': Icons.auto_awesome,
      'festival-vibes': Icons.local_fire_department,
      'logo-lab': Icons.draw,
      'poster-house': Icons.image,
      'product-ads': Icons.shopping_bag,
      'art-styles': Icons.palette,
      'trending': Icons.trending_up,
    };
    final latest = Store.prompts.take(6).toList();
    return ListView(padding: const EdgeInsets.all(18), children: [
      // Top bar
      Row(children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.asset('assets/logo.png', width: 40, height: 40, fit: BoxFit.cover),
        ),
        const SizedBox(width: 10),
        Text('ROYAL TREASURY', style: Pm.serif(16).copyWith(color: Pm.gold, letterSpacing: 2, fontWeight: FontWeight.w700)),
        const Spacer(),
        IconButton(
          icon: const Icon(Icons.notifications_outlined, color: Pm.gold),
          onPressed: () {
            showDialog(context: context, builder: (c) => AlertDialog(
              backgroundColor: Pm.card,
              title: Text('Royal Announcement', style: Pm.serif(18).copyWith(color: Pm.gold)),
              content: const Text('The treasury is quiet today. New royal prompts arrive every week — keep creating, Maharaja.', style: TextStyle(color: Pm.cream)),
              actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK', style: TextStyle(color: Pm.gold)))],
            ));
          },
        ),
      ]),
      const SizedBox(height: 20),
      // Greeting
      RichText(text: TextSpan(children: [
        TextSpan(text: 'Hello, ', style: Pm.serif(28).copyWith(color: Colors.white)),
        TextSpan(text: 'Maharaja', style: Pm.serif(28).copyWith(color: Pm.gold, fontWeight: FontWeight.w700)),
      ])),
      const SizedBox(height: 4),
      const Text('What shall we create today?', style: TextStyle(color: Pm.muted, fontSize: 14)),
      const SizedBox(height: 16),
      // Search bar
      GestureDetector(
        onTap: () => context.findAncestorStateOfType<ShellState>()?.go(2),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
          child: const Row(children: [
            Icon(Icons.search, color: Pm.muted, size: 20),
            SizedBox(width: 10),
            Text('Search royal prompts...', style: TextStyle(color: Pm.muted, fontSize: 14)),
          ]),
        ),
      ),
      const SizedBox(height: 22),
      // Categories header
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Categories', style: Pm.serif(20).copyWith(fontWeight: FontWeight.w700)),
        GestureDetector(
          onTap: () => context.findAncestorStateOfType<ShellState>()?.go(1),
          child: const Row(children: [
            Text('See all', style: TextStyle(color: Pm.gold, fontSize: 14)),
            Icon(Icons.chevron_right, color: Pm.gold, size: 18),
          ]),
        ),
      ]),
      const SizedBox(height: 12),
      // Categories grid (2x2, show first 4, rest in categories page)
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.1),
        itemCount: Store.cats.length,
        itemBuilder: (_, i) {
          final cat = Store.cats[i];
          return _catCard(context, cat, icons[cat.id] ?? Icons.auto_awesome);
        },
      ),
      const SizedBox(height: 22),
      // AI Image Studio card
      GestureDetector(
        onTap: () => context.findAncestorStateOfType<ShellState>()?.go(4),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Pm.card, borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Pm.gold, width: 1.5),
          ),
          child: Row(children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(color: Pm.gold.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.auto_awesome, color: Pm.gold, size: 26),
            ),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('AI Image Studio', style: TextStyle(color: Pm.gold, fontSize: 16, fontWeight: FontWeight.w700)),
              SizedBox(height: 4),
              Text('Generate royal images from your words — free', style: TextStyle(color: Pm.muted, fontSize: 13)),
            ])),
            const Icon(Icons.arrow_forward_ios, color: Pm.gold, size: 18),
          ]),
        ),
      ),
      const SizedBox(height: 22),
      // Latest Prompts header
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text('Latest Prompts', style: Pm.serif(20).copyWith(fontWeight: FontWeight.w700)),
        GestureDetector(
          onTap: () => context.findAncestorStateOfType<ShellState>()?.go(1),
          child: const Row(children: [
            Text('See all', style: TextStyle(color: Pm.gold, fontSize: 14)),
            Icon(Icons.chevron_right, color: Pm.gold, size: 18),
          ]),
        ),
      ]),
      const SizedBox(height: 12),
      ...latest.map((p) => _promptCard(context, p)),
      const SizedBox(height: 16),
      // Maharaja's Tip
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.lightbulb_outline, color: Pm.gold, size: 20),
            const SizedBox(width: 8),
            Text("Maharaja's Tip", style: Pm.serif(16).copyWith(color: Pm.gold, fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 10),
          const Text('Longer, detailed prompts create more majestic images. Describe light, mood, and textures like a royal painter.', style: TextStyle(color: Pm.cream, fontSize: 14, height: 1.5)),
        ]),
      ),
      const SizedBox(height: 20),
    ]);
  }
}
