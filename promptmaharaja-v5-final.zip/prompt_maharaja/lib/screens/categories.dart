
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import 'category_detail.dart';
class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      Text('Categories', style: Pm.serif(26).copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 4),
      const Text('Pick a royal style to explore', style: Pm.small),
      const SizedBox(height: 16),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.05),
        itemCount: Store.cats.length,
        itemBuilder: (_, i) {
          final cat = Store.cats[i];
          final n = Store.prompts.where((p) => p.cat == cat.id).length;
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryDetail(cat: cat))),
            child: Pm.cardBox(Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.auto_awesome, color: Pm.gold, size: 26),
              const SizedBox(height: 10),
              Text(cat.name, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(cat.blurb, style: Pm.small, maxLines: 2, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 6),
              Text('$n prompts', style: const TextStyle(color: Pm.gold, fontSize: 12, fontWeight: FontWeight.w600)),
            ])));
        }),
    ]);
  }
}
