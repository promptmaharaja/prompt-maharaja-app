
import 'package:flutter/material.dart';
import '../theme.dart';
import 'legal.dart';
class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});
  Widget _stat(String n, String l) => Expanded(child: Container(
    margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.symmetric(vertical: 14),
    decoration: BoxDecoration(border: Border.all(color: Pm.line), borderRadius: BorderRadius.circular(14)),
    child: Column(children: [
      Text(n, style: Pm.serif(24).copyWith(color: Pm.gold, fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      Text(l, textAlign: TextAlign.center, style: const TextStyle(color: Pm.muted, fontSize: 11, letterSpacing: 1)),
    ])));
  Widget _step(String n, String t, String d) => Container(
    margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
    child: Row(children: [
      Container(width: 44, height: 44,
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Pm.gold)), alignment: Alignment.center,
        child: Text(n, style: Pm.serif(18).copyWith(color: Pm.gold, fontWeight: FontWeight.w700))),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(d, style: Pm.small),
      ])),
    ]));
  @override
  Widget build(BuildContext context) {
    final legals = [
      ['Privacy Policy', LegalTexts.privacy],
      ['Terms of Use', LegalTexts.terms],
      ['Licence', LegalTexts.licence],
      ['Refund Policy', LegalTexts.refund],
      ['About Us', LegalTexts.about],
      ['Contact Us', LegalTexts.contact],
    ];
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      Text('More', style: Pm.serif(26).copyWith(fontWeight: FontWeight.w600)),
      const SizedBox(height: 16),
      Pm.cardBox(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.info_outline, color: Pm.gold, size: 20), SizedBox(width: 8),
          Text('ABOUT THE TREASURY', style: TextStyle(color: Pm.gold, letterSpacing: 2, fontSize: 13, fontWeight: FontWeight.w700))]),
        const SizedBox(height: 12),
        const Text('Prompt Maharaja is a royal treasury of hand-crafted AI image prompts. Each prompt is written like a director’s brief — rich, visual and ready to paste into your favourite AI art generator.', style: Pm.body),
        const SizedBox(height: 14),
        Row(children: [_stat('29', 'CURATED
PROMPTS'), _stat('9', 'CATEGORIES'), _stat('100%', 'FREE')]),
      ])),
      const SizedBox(height: 20),
      const Text('HOW TO USE', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 13, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      _step('1', 'Browse the treasury', 'Wander through categories or search for a mood — warrior, neon, logo, anime.'),
      _step('2', 'Copy the royal decree', 'Open any prompt and tap Copy Prompt. It lands on your clipboard instantly.'),
      _step('3', 'Create and reign', 'Paste it into your favourite AI art app and watch the magic unfold.'),
      const SizedBox(height: 20),
      Container(), // Admin removed
        child: Container(margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFFF0D878), Color(0xFFC9A227)]),
            borderRadius: BorderRadius.circular(16)),
          child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text('👑', style: TextStyle(fontSize: 20)),
            SizedBox(width: 8),
            Text('ADMIN PANEL', style: TextStyle(color: Color(0xFF1A1405), fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 2)),
          ]))),
      const Text('LEGAL', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 13, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      ...legals.map((l) => GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LegalPage(title: l[0], body: l[1]))),
        child: Container(margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(l[0], style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600)),
            const Icon(Icons.chevron_right, color: Pm.gold, size: 20),
          ])))),
      const SizedBox(height: 16),
      const Center(child: Text('PROMPT MAHARAJA', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 13, fontWeight: FontWeight.w700))),
      const SizedBox(height: 6),
      const Center(child: Text('Crafted for creators, with love.', style: TextStyle(color: Pm.muted, fontStyle: FontStyle.italic))),
      const SizedBox(height: 4),
      const Center(child: Text('Made with ❤️ Arts Studios by SULTAN', style: TextStyle(color: Pm.muted, fontStyle: FontStyle.italic))),
    ]);
  }
}
