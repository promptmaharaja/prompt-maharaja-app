
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import '../favs.dart';
import 'prompt_detail.dart';
class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}
class _FavoritesScreenState extends State<FavoritesScreen> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Set<String>>(
      future: Favs.get(),
      builder: (_, snap) {
        final favIds = snap.data ?? {};
        final list = Store.prompts.where((p) => favIds.contains(p.id)).toList();
        return ListView(padding: const EdgeInsets.all(18), children: [
          const SizedBox(height: 8),
          const Text('YOUR TREASURY', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12)),
          const SizedBox(height: 6),
          Text('Favorites', style: Pm.serif(30).copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text('Tap the heart on any prompt to save it here.', style: Pm.small),
          const SizedBox(height: 16),
          if (list.isEmpty)
            Pm.cardBox(Column(children: [
              const SizedBox(height: 10),
              Container(width: 70, height: 70,
                decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Pm.gold)),
                child: const Icon(Icons.favorite_outline, color: Pm.gold, size: 34)),
              const SizedBox(height: 16),
              Text('No favorites yet', style: Pm.serif(22).copyWith(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              const Text('The treasury awaits your choices.', style: Pm.small, textAlign: TextAlign.center),
              const SizedBox(height: 16),
            ]))
          else ...list.map((p) => Dismissible(
            key: ValueKey(p.id), direction: DismissDirection.endToStart,
            background: Container(alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20),
              decoration: BoxDecoration(color: Colors.red.shade900, borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.delete, color: Colors.white)),
            onDismissed: (_) async { await Favs.toggle(p.id); setState(() {}); },
            child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetail(prompt: p)))
                .then((_) => setState(() {})),
              child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
                child: Row(children: [
                  Expanded(child: Text(p.title, style: Pm.serif(15).copyWith(fontWeight: FontWeight.w600))),
                  const Icon(Icons.favorite, color: Pm.gold, size: 18),
                ]))))),
        ]);
      });
  }
}
