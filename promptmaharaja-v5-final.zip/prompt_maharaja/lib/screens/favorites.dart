
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/store.dart';
import '../favs.dart';
import '../shell.dart';
import 'prompt_detail.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  @override
  void initState() { super.initState(); Favs.load().then((_) => setState(() {})); }

  @override
  Widget build(BuildContext context) {
    final favs = Store.prompts.where((p) => Favs.ids.contains(p.id)).toList();
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      const Text('YOUR TREASURY', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text('Favorites', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      const Text('Tap the heart on any prompt to save it here.', style: TextStyle(color: Pm.muted, fontSize: 14)),
      const SizedBox(height: 24),
      if (favs.isEmpty)
        Column(children: [
          const SizedBox(height: 40),
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Pm.gold.withOpacity(0.3))),
            child: const Icon(Icons.favorite_border, color: Pm.gold, size: 36),
          ),
          const SizedBox(height: 20),
          Text('No favorites yet', style: Pm.serif(20).copyWith(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('Your saved prompts will appear here.', style: TextStyle(color: Pm.muted)),
          const SizedBox(height: 24),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Pm.gold, padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () => context.findAncestorStateOfType<ShellState>()?.go(0),
            child: const Text('Explore Prompts', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w700)),
          ),
        ])
      else
        ...favs.map((p) => Dismissible(
          key: Key(p.id),
          direction: DismissDirection.endToStart,
          background: Container(alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20), decoration: BoxDecoration(color: Colors.red.withOpacity(0.2), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.delete, color: Colors.red)),
          onDismissed: (_) { Favs.toggle(p.id); setState(() {}); },
          child: GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetailPage(prompt: p))).then((_) => setState(() {})),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
              child: Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p.title, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(Store.catName(p.cat), style: Pm.small),
                ])),
                const Icon(Icons.favorite, color: Pm.gold, size: 20),
              ]),
            ),
          ),
        )),
    ]);
  }
}
