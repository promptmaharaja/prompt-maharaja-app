import 'package:flutter/material.dart';
import '../theme.dart';

class LegalTexts {
  static const privacy = '''
WHAT WE COLLECT

Prompt Maharaja respects your privacy. We do not collect personal information. Favourite prompts are stored only on your device.

HOW WE USE IT

The AI image generator sends your typed prompt to the image service to create pictures \u2014 nothing else leaves your phone.

ADVERTISING

Advertisements shown in the app are served by Google AdMob and may use standard advertising identifiers as per Google\u2019s policy.

DATA STORAGE

Your favorites and settings stay on your device. We do not upload your personal data to our servers.

CONTACT

Questions? Email us at hello@promptmaharaja.in
''';

  static const terms = '''
AGREEMENT

By using Prompt Maharaja you agree to these terms.

USE OF PROMPTS

All prompts are provided for creative inspiration. Generated images belong to you for personal and commercial use as per the image service\u2019s own terms.

FAIR USE

Do not misuse the app to create unlawful or harmful content. We may update the app and these terms at any time.
''';

  static const licence = '''
GRANT

Prompt Maharaja grants you a personal, non-transferable licence to use the app and its prompt collection.

PERMITTED USE

You may copy and use prompts in your own creative work.

RESTRICTIONS

You may not resell the prompt collection itself or redistribute the app\u2019s content as a competing product.
''';

  static const refund = '''
FREE APP

Prompt Maharaja is free to use and contains no in-app purchases.

FUTURE PURCHASES

If paid features are introduced in future, refunds will follow the Google Play Store\u2019s standard refund policy.
''';

  static const about = '''
OUR STORY

Prompt Maharaja is a royal treasury of hand-crafted AI image prompts, created by Arts Studios by SULTAN.

WHAT WE DO

Every prompt is written like a director\u2019s brief \u2014 rich, visual and ready to paste into your favourite AI art generator.
''';

  static const contact = '''
GET IN TOUCH

Questions, feedback or ideas?

EMAIL

Email us at hello@promptmaharaja.in

RESPONSE

We read every message and reply as soon as we can.
''';
}

class LegalPage extends StatelessWidget {
  final String title, body;
  const LegalPage({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pm.bg,
      appBar: AppBar(
        backgroundColor: Pm.bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Pm.cream),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(title, style: Pm.serif(22)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Pm.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Pm.line),
            ),
            child: Text(
              body.trim(),
              style: const TextStyle(color: Pm.cream, fontSize: 15, height: 1.7),
            ),
          ),
        ],
      ),
    );
  }
}
