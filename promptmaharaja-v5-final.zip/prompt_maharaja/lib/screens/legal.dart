
import 'package:flutter/material.dart';
import '../theme.dart';
class LegalTexts {
  static const privacy = 'Prompt Maharaja respects your privacy.\n\nWe do not collect personal information. Favourite prompts are stored only on your device. The AI image generator sends your typed prompt to the image service to create pictures \u2014 nothing else leaves your phone.\n\nAdvertisements shown in the app are served by Google AdMob and may use standard advertising identifiers as per Google\u2019s policy.';
  static const terms = 'By using Prompt Maharaja you agree to these terms.\n\nAll prompts are provided for creative inspiration. Generated images belong to you for personal and commercial use as per the image service\u2019s own terms.\n\nDo not misuse the app to create unlawful or harmful content. We may update the app and these terms at any time.';
  static const licence = 'Prompt Maharaja grants you a personal, non-transferable licence to use the app and its prompt collection.\n\nYou may copy and use prompts in your own creative work. You may not resell the prompt collection itself or redistribute the app\u2019s content as a competing product.';
  static const refund = 'Prompt Maharaja is free to use and contains no in-app purchases.\n\nIf paid features are introduced in future, refunds will follow the Google Play Store\u2019s standard refund policy.';
  static const about = 'Prompt Maharaja is a royal treasury of hand-crafted AI image prompts, created by Arts Studios by SULTAN.\n\nEvery prompt is written like a director\u2019s brief \u2014 rich, visual and ready to paste into your favourite AI art generator.';
  static const contact = 'Questions, feedback or ideas?\n\nEmail us at hello@promptmaharaja.in\n\nWe read every message and reply as soon as we can.';
}
class LegalPage extends StatelessWidget {
  final String title, body;
  const LegalPage({super.key, required this.title, required this.body});
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Pm.bg,
      appBar: AppBar(title: Text(title, style: Pm.serif(20))),
      body: ListView(padding: const EdgeInsets.all(18),
        children: [Pm.cardBox(Text(body, style: Pm.body))]));
  }
}
