import 'package:flutter/material.dart';
import '../theme.dart';

class LegalTexts {
  static const privacy = 'WHAT WE COLLECT\n\nPrompt Maharaja respects your privacy. We do not collect personal information. Favourite prompts are stored only on your device.\n\nHOW WE USE IT\n\nThe AI image generator sends your typed prompt to the image service to create pictures \u2014 nothing else leaves your phone.\n\nADVERTISING\n\nAdvertisements shown in the app are served by Google AdMob and may use standard advertising identifiers as per Google\u2019s policy.\n\nDATA STORAGE\n\nYour favorites and settings stay on your device. We do not upload your personal data to our servers.\n\nCONTACT\n\nQuestions? Email us at hello@promptmaharaja.in';

  static const terms = 'AGREEMENT\n\nBy using Prompt Maharaja you agree to these terms.\n\nUSE OF PROMPTS\n\nAll prompts are provided for creative inspiration. Generated images belong to you for personal and commercial use as per the image service\u2019s own terms.\n\nFAIR USE\n\nDo not misuse the app to create unlawful or harmful content. We may update the app and these terms at any time.';

  static const licence = 'GRANT\n\nPrompt Maharaja grants you a personal, non-transferable licence to use the app and its prompt collection.\n\nPERMITTED USE\n\nYou may copy and use prompts in your own creative work.\n\nRESTRICTIONS\n\nYou may not resell the prompt collection itself or redistribute the app\u2019s content as a competing product.';

  static const refund = 'FREE APP\n\nPrompt Maharaja is free to use and contains no in-app purchases.\n\nFUTURE PURCHASES\n\nIf paid features are introduced in future, refunds will follow the Google Play Store\u2019s standard refund policy.';

  static const about = 'OUR STORY\n\nPrompt Maharaja is a royal treasury of hand-crafted AI image prompts, created by Arts Studios by SULTAN.\n\nWHAT WE DO\n\nEvery prompt is written like a director\u2019s brief \u2014 rich, visual and ready to paste into your favourite AI art generator.';

  static const contact = 'GET IN TOUCH\n\nQuestions, feedback or ideas?\n\nEMAIL\n\nEmail us at hello@promptmaharaja.in\n\nRESPONSE\n\nWe read every message and reply as soon as we can.';
}

class LegalPage extends StatelessWidget {
  final String title, body;
  const LegalPage({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    final sections = <Map<String,String>>[];
    String? curH;
    final curB = <String>[];
    for (final line in body.split('\n')) {
      final t = line.trim();
      if (t.isEmpty) continue;
      if (t == t.toUpperCase() && t.length < 30 && !t.contains('.') && t.length > 3 && RegExp(r'^[A-Z ]+\$').hasMatch(t)) {
        if (curH != null) sections.add({'h': curH, 'b': curB.join('\n\n')});
        curH = t;
        curB.clear();
      } else {
        curB.add(t);
      }
    }
    if (curH != null) sections.add({'h': curH, 'b': curB.join('\n\n')});

    return Scaffold(
      backgroundColor: Pm.bg,
      appBar: AppBar(
        backgroundColor: Pm.bg,
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Pm.cream), onPressed: () => Navigator.pop(context)),
        title: Text(title, style: Pm.serif(22)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final s in sections) ...[
                  Text(s['h']!, style: const TextStyle(color: Pm.gold, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 2)),
                  const SizedBox(height: 8),
                  Text(s['b']!, style: const TextStyle(color: Pm.cream, fontSize: 15, height: 1.6)),
                  const SizedBox(height: 20),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
