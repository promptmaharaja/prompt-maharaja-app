
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../data/prompts.dart';
import '../data/store.dart';

// Exact replica of Maharaja Admin HTML demo - with Firebase instead of localStorage
class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _col = FirebaseFirestore.instance.collection('prompts');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0A0A), elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFFD4AF37)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: const SingleChildScrollView(child: _AdminBody()),
    );
  }
}

class _AdminBody extends StatefulWidget {
  const _AdminBody();
  @override
  State<_AdminBody> createState() => _AdminBodyState();
}

class _AdminBodyState extends State<_AdminBody> {
  final _col = FirebaseFirestore.instance.collection('prompts');
  final _title = TextEditingController();
  final _prompt = TextEditingController();
  final _neg = TextEditingController();
  String _cat = 'Royal Portraits';
  String? _editId;
  bool _saving = false;
  bool _ddOpen = false;

  static const _cats = ['Royal Portraits','Cinematic','Anime World','Festival Vibes','Logo Lab','Poster House','Product Ads','Art Styles','Trending Prompts'];

  static const _bg = Color(0xFF0A0A0A);
  static const _cream = Color(0xFFF5F0E1);
  static const _gold = Color(0xFFD4AF37);
  static const _muted = Color(0xFF9A8F6A);
  static const _card = Color(0xFF141310);
  static const _cardBorder = Color(0xFF3A2F14);
  static const _input = Color(0xFF0C0B09);
  static const _inputBorder = Color(0xFF4A3D1C);

  TextStyle get _serif => const TextStyle(fontFamily: 'Georgia', color: _cream);

  @override
  void dispose() {
    _title.dispose(); _prompt.dispose(); _neg.dispose();
    super.dispose();
  }

  void _pickCat(String c) => setState(() { _cat = c; _ddOpen = false; });

  void _clearForm() => setState(() {
    _title.clear(); _prompt.clear(); _neg.clear();
    _cat = _cats[0]; _editId = null;
  });

  Future<void> _upload() async {
    final t = _title.text.trim(), p = _prompt.text.trim(), n = _neg.text.trim();
    if (t.isEmpty || p.isEmpty) {
      _toast('⚠ Title aur Prompt dono likho');
      return;
    }
    setState(() => _saving = true);
    try {
      final data = {
        'title': t, 'prompt': p, 'cat': _cat, 'neg': n,
        'tags': <String>[], 'isNew': true,
        'updatedAt': FieldValue.serverTimestamp(),
      };
      if (_editId != null) {
        await _col.doc(_editId!).update(data);
        _toast('✅ Prompt update ho gaya!');
      } else {
        data['createdAt'] = FieldValue.serverTimestamp();
        await _col.add(data);
        _toast('✅ Prompt upload ho gaya!');
      }
      _clearForm();
    } catch (e) {
      _toast('Error: $e');
    }
    if (mounted) setState(() => _saving = false);
  }

  void _toast(String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(m, textAlign: TextAlign.center),
      backgroundColor: const Color(0xFF1D1A0E),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30), side: const BorderSide(color: _gold)),
    ));
  }

  void _editDoc(DocumentSnapshot d) {
    final m = d.data() as Map<String, dynamic>;
    setState(() {
      _cat = (m['cat'] ?? _cats[0]).toString();
      if (!_cats.contains(_cat)) _cat = _cats[0];
      _title.text = (m['title'] ?? '').toString();
      _prompt.text = (m['prompt'] ?? '').toString();
      _neg.text = (m['neg'] ?? '').toString();
      _editId = d.id;
    });
    Scrollable.ensureVisible(context, duration: const Duration(milliseconds: 300));
  }

  Future<void> _deleteDoc(String id) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      backgroundColor: _card,
      title: const Text('Delete?', style: TextStyle(color: _gold, fontFamily: 'Georgia')),
      content: const Text('Delete this prompt?', style: TextStyle(color: _cream)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel', style: TextStyle(color: _muted))),
        TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete', style: TextStyle(color: Colors.red))),
      ],
    ));
    if (ok == true) {
      await _col.doc(id).delete();
      _toast('🗑 Prompt delete ho gaya');
    }
  }

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(top: 14, bottom: 6),
    child: Text(t.toUpperCase(), style: const TextStyle(fontSize: 11, letterSpacing: 2, color: _gold, fontWeight: FontWeight.w600)),
  );

  Widget _input(TextEditingController c, String hint, {int lines = 1}) => TextField(
    controller: c, maxLines: lines, style: _serif.copyWith(fontSize: 15),
    decoration: InputDecoration(
      hintText: hint, hintStyle: const TextStyle(color: _muted),
      filled: true, fillColor: _input,
      contentPadding: const EdgeInsets.all(12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _inputBorder)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _inputBorder)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _gold)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Center(child: Container(
      constraints: const BoxConstraints(maxWidth: 420),
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 40),
      child: Column(children: [
        // Header
        const Text('👑', style: TextStyle(fontSize: 38)),
        const SizedBox(height: 8),
        Text('MAHARAJA ADMIN', style: _serif.copyWith(fontSize: 26, color: _gold, letterSpacing: 2, fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        const Text('PROMPT UPLOAD PANEL', style: TextStyle(fontSize: 12, color: _muted, letterSpacing: 3)),
        const SizedBox(height: 6),

        // Form Card
        Container(
          margin: const EdgeInsets.only(top: 18),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(14), border: Border.all(color: _cardBorder)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _label('Category'),
            // Custom dropdown
            Column(children: [
              GestureDetector(
                onTap: () => setState(() => _ddOpen = !_ddOpen),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                  decoration: BoxDecoration(color: _input, borderRadius: BorderRadius.circular(10), border: Border.all(color: _gold)),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text(_cat, style: _serif.copyWith(fontSize: 16)),
                    const Text('▾', style: TextStyle(color: _gold, fontSize: 14)),
                  ]),
                ),
              ),
              if (_ddOpen) Container(
                margin: const EdgeInsets.only(top: 6),
                decoration: BoxDecoration(color: const Color(0xFF17150F), borderRadius: BorderRadius.circular(10), border: Border.all(color: _gold)),
                child: Column(children: _cats.map((c) => GestureDetector(
                  onTap: () => _pickCat(c),
                  child: Container(
                    width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: const Color(0xFF2A2415), width: c == _cats.last ? 0 : 1))),
                    child: Text(c, style: _serif.copyWith(fontSize: 15, color: c == _cat ? _gold : _cream, fontWeight: c == _cat ? FontWeight.bold : FontWeight.normal)),
                  ),
                )).toList()),
              ),
            ]),
            _label('Title'),
            _input(_title, 'e.g. Rajput Warrior at Dawn'),
            _label('Prompt'),
            _input(_prompt, 'Full detailed prompt yahan likho...', lines: 5),
            _label('Negative Prompt (optional)'),
            _input(_neg, 'e.g. blurry, watermark, low quality'),
            const SizedBox(height: 18),
            // Upload button with gold gradient
            SizedBox(width: double.infinity, child: GestureDetector(
              onTap: _saving ? null : _upload,
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 15),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFF0D878), Color(0xFFC9A227)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(child: _saving
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Color(0xFF1A1405), strokeWidth: 2))
                  : Text(_editId != null ? '💾 SAVE CHANGES' : '⬆ UPLOAD PROMPT',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1, color: Color(0xFF1A1405), fontFamily: 'Georgia'))),
              ),
            )),
            if (_editId != null) Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(width: double.infinity, child: OutlinedButton(
                style: OutlinedButton.styleFrom(side: const BorderSide(color: _muted), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                onPressed: _clearForm,
                child: const Text('Cancel Edit', style: TextStyle(color: _muted)),
              )),
            ),
          ]),
        ),

        // Stats
        StreamBuilder<QuerySnapshot>(
          stream: _col.snapshots(),
          builder: (c, snap) {
            final count = snap.hasData ? snap.data!.docs.length : 0;
            return Padding(padding: const EdgeInsets.only(top: 18), child: Row(children: [
              Expanded(child: _stat(count.toString(), 'TOTAL PROMPTS')),
              const SizedBox(width: 10),
              Expanded(child: _stat('9', 'CATEGORIES')),
            ]));
          },
        ),

        // Uploaded list header
        Padding(padding: const EdgeInsets.only(top: 26, bottom: 4), child: Align(
          alignment: Alignment.centerLeft,
          child: Text('📋 UPLOADED PROMPTS', style: _serif.copyWith(fontSize: 15, letterSpacing: 2, color: _gold)),
        )),

        // List
        StreamBuilder<QuerySnapshot>(
          stream: _col.orderBy('createdAt', descending: true).snapshots(),
          builder: (c, snap) {
            if (snap.hasError) return const Padding(padding: EdgeInsets.all(20), child: Text('Error loading', style: TextStyle(color: Colors.red)));
            if (!snap.hasData) return const Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(color: _gold));
            final docs = snap.data!.docs;
            if (docs.isEmpty) return Container(
              margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _cardBorder)),
              child: const Center(child: Text('Abhi koi prompt nahi hai.\nUpar form se pehla prompt upload karo 👑',
                textAlign: TextAlign.center, style: TextStyle(color: _muted))),
            );
            return Column(children: docs.map((d) {
              final m = d.data() as Map<String, dynamic>;
              final title = (m['title'] ?? '').toString();
              final cat = (m['cat'] ?? '').toString();
              final prompt = (m['prompt'] ?? '').toString();
              return Container(
                margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _cardBorder)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: _gold, borderRadius: BorderRadius.circular(4)),
                    child: Text(cat.toUpperCase(), style: const TextStyle(fontSize: 10, letterSpacing: 1, color: Color(0xFF1A1405), fontWeight: FontWeight.w600)),
                  ),
                  const SizedBox(height: 8),
                  Text(title, style: _serif.copyWith(fontSize: 16, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(prompt, style: _serif.copyWith(fontSize: 13, color: _muted), maxLines: 3, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: GestureDetector(
                      onTap: () => _editDoc(d),
                      child: Container(padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(border: Border.all(color: _gold), borderRadius: BorderRadius.circular(8)),
                        child: const Center(child: Text('✏ Edit', style: TextStyle(color: _gold, fontSize: 13)))),
                    )),
                    const SizedBox(width: 8),
                    Expanded(child: GestureDetector(
                      onTap: () => _deleteDoc(d.id),
                      child: Container(padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(border: Border.all(color: Colors.red.shade800), borderRadius: BorderRadius.circular(8)),
                        child: Center(child: Text('🗑 Delete', style: TextStyle(color: Colors.red.shade400, fontSize: 13)))),
                    )),
                  ]),
                ]),
              );
            }).toList());
          },
        ),

        const Padding(padding: EdgeInsets.only(top: 20), child: Text(
          'Firebase se sab devices pe sync hoga.',
          textAlign: TextAlign.center, style: TextStyle(color: _muted, fontSize: 12),
        )),
      ]),
    ));
  }

  Widget _stat(String n, String l) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12), border: Border.all(color: _cardBorder)),
    child: Column(children: [
      Text(n, style: _serif.copyWith(fontSize: 24, color: _gold, fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      Text(l, style: const TextStyle(fontSize: 11, color: _muted, letterSpacing: 1)),
    ]),
  );
}
