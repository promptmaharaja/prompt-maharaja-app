
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import 'prompt_detail.dart';
class CategoryDetail extends StatelessWidget {
  final PmCategory cat;
  const CategoryDetail({super.key, required this.cat});
  @override
  Widget build(BuildContext context) {
    final list = Store.prompts.where((p) => p.cat == cat.id).toList();
    return Scaffold(backgroundColor: Pm.bg,
      appBar: AppBar(title: Text(cat.name, style: Pm.serif(20))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text(cat.blurb, style: Pm.small),
        const SizedBox(height: 4),
        Text('${list.length} prompts', style: const TextStyle(color: Pm.gold, fontSize: 13, fontWeight: FontWeight.w600)),
        const SizedBox(height: 14),
        ...list.map((p) => GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetail(prompt: p))),
          child: Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
            child: Row(children: [
              Container(width: 52, height: 52,
                decoration: BoxDecoration(color: Pm.gold.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.image_outlined, color: Pm.gold)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(p.title, style: Pm.serif(15).copyWith(fontWeight: FontWeight.w600))),
                  if (p.isNew) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: Pm.gold, borderRadius: BorderRadius.circular(10)),
                    child: const Text('NEW', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Colors.black))),
                ]),
                const SizedBox(height: 6),
                Text(p.text, style: Pm.small, maxLines: 2, overflow: TextOverflow.ellipsis),
              ])),
              const Icon(Icons.chevron_right, color: Pm.muted),
            ])))),
      ]));
  }
}
