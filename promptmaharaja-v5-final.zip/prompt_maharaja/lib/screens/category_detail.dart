import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import '../favs.dart';
import 'prompt_detail.dart';

class CategoryDetailPage extends StatefulWidget {
  final PmCategory cat;
  const CategoryDetailPage({super.key, required this.cat});
  @override
  State<CategoryDetailPage> createState() => _CategoryDetailPageState();
}

class _CategoryDetailPageState extends State<CategoryDetailPage> {
  @override
  void initState() { super.initState(); Favs.load().then((_) => setState(() {})); }

  @override
  Widget build(BuildContext context) {
    final prompts = Store.prompts.where((p) => p.cat == widget.cat.id).toList();
    return Scaffold(
      backgroundColor: Pm.bg,
      appBar: AppBar(
        backgroundColor: Pm.bg, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Pm.cream), onPressed: () => Navigator.pop(context)),
        title: Text(widget.cat.name, style: Pm.serif(22).copyWith(fontWeight: FontWeight.w700)),
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text('${prompts.length} royal prompts', style: Pm.small),
        const SizedBox(height: 4),
        Text(widget.cat.blurb, style: const TextStyle(color: Pm.muted, fontSize: 14)),
        const SizedBox(height: 18),
        ...prompts.map((p) {
          final isFav = Favs.ids.contains(p.id);
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PromptDetailPage(prompt: p))).then((_) => setState(() {})),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(p.title, style: Pm.serif(17).copyWith(fontWeight: FontWeight.w700))),
                  GestureDetector(
                    onTap: () { Favs.toggle(p.id); setState(() {}); },
                    child: Icon(isFav ? Icons.favorite : Icons.favorite_border, color: Pm.gold, size: 22),
                  ),
                ]),
                const SizedBox(height: 8),
                Text(p.text, style: const TextStyle(color: Pm.muted, fontSize: 13), maxLines: 2, overflow: TextOverflow.ellipsis),
                const SizedBox(height: 8),
                const Row(children: [
                  Text('View prompt', style: TextStyle(color: Pm.gold, fontSize: 13)),
                  SizedBox(width: 4),
                  Icon(Icons.arrow_forward, color: Pm.gold, size: 14),
                ]),
              ]),
            ),
          );
        }),
      ]),
    );
  }
}
