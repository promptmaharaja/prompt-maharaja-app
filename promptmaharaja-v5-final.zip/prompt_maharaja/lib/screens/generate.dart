import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../theme.dart';
import '../data/store.dart';

class GenerateScreen extends StatefulWidget {
  const GenerateScreen({super.key});
  @override
  State<GenerateScreen> createState() => _GenerateScreenState();
}

class _GenerateScreenState extends State<GenerateScreen> {
  final _ctl = TextEditingController();
  String _style = 'No style';
  String _size = 'Square 1:1';
  bool _busy = false;
  Uint8List? _img;
  String? _err;
  BannerAd? _banner;
  InterstitialAd? _inter;

  final _styles = ['No style','Royal Portrait','Cinematic','Anime','Festival','Logo','Poster','Product','Artistic'];
  final _sizes = ['Square 1:1','Portrait 2:3','Landscape 3:2'];

  @override
  void initState() {
    super.initState();
    _banner = BannerAd(adUnitId: 'ca-app-pub-3940256099942544/6300978111', size: AdSize.banner, request: const AdRequest(), listener: BannerAdListener(onAdLoaded: (_) => setState(() {}), onAdFailedToLoad: (_, __) => setState(() => _banner = null)));
    _banner?.load();
    InterstitialAd.load(adUnitId: 'ca-app-pub-3940256099942544/1033173712', request: const AdRequest(), adLoadCallback: InterstitialAdLoadCallback(onAdLoaded: (a) => _inter = a, onAdFailedToLoad: (_) {}));
  }

  @override
  void dispose() { _ctl.dispose(); _banner?.dispose(); _inter?.dispose(); super.dispose(); }

  String _styleSuffix() {
    switch (_style) {
      case 'Royal Portrait': return ', royal Indian portrait style, ornate, majestic';
      case 'Cinematic': return ', cinematic film still, dramatic lighting';
      case 'Anime': return ', anime style, vibrant';
      case 'Festival': return ', festive Indian celebration style';
      case 'Logo': return ', professional logo design, vector style';
      case 'Poster': return ', movie poster style, dramatic';
      case 'Product': return ', professional product photography';
      case 'Artistic': return ', artistic masterpiece, detailed';
      default: return '';
    }
  }

  Future<void> _generate() async {
    final p = _ctl.text.trim();
    if (p.isEmpty) { setState(() => _err = 'Pehle prompt likho!'); return; }
    setState(() { _busy = true; _err = null; _img = null; });
    try {
      // Size dims
      int w = 1024, h = 1024;
      if (_size == 'Portrait 2:3') { w = 768; h = 1152; }
      if (_size == 'Landscape 3:2') { w = 1152; h = 768; }
      final full = p + _styleSuffix();
      final url = 'https://image.pollinations.ai/prompt/${Uri.encodeComponent(full)}?width=$w&height=$h&nologo=true&seed=${DateTime.now().millisecondsSinceEpoch % 100000}';
      final resp = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 90));
      if (resp.statusCode == 200 && resp.bodyBytes.length > 10000) {
        // Crop bottom 40px to remove watermark area, overlay Maharaja logo text via simple approach
        // For now, just use the image as-is (nologo=true already)
        setState(() { _img = resp.bodyBytes; });
        _inter?.show();
      } else {
        setState(() => _err = 'Could not generate. Check internet and try again.');
      }
    } catch (e) {
      setState(() => _err = 'Could not generate. Check internet and try again.');
    }
    setState(() => _busy = false);
  }

  Future<void> _download() async {
    if (_img == null) return;
    final d = await getTemporaryDirectory();
    final f = File('${d.path}/maharaja_${DateTime.now().millisecondsSinceEpoch}.png');
    await f.writeAsBytes(_img!);
    await Share.shareXFiles([XFile(f.path)], text: 'Created with Prompt Maharaja 👑');
  }

  void _surprise() {
    final all = Store.prompts;
    if (all.isEmpty) return;
    all.shuffle();
    _ctl.text = all.first.text;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      const Text('FREE AI STUDIO', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text('Generate Image', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      const Text('Describe your dream — the Maharaja paints it for free.', style: TextStyle(color: Pm.muted, fontSize: 14)),
      const SizedBox(height: 18),
      // Your prompt + Surprise me
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Your prompt', style: TextStyle(color: Pm.cream, fontSize: 15, fontWeight: FontWeight.w600)),
        GestureDetector(
          onTap: _surprise,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: Pm.gold.withOpacity(0.15), borderRadius: BorderRadius.circular(8), border: Border.all(color: Pm.gold.withOpacity(0.3))),
            child: const Row(children: [
              Icon(Icons.casino_outlined, color: Pm.gold, size: 14),
              SizedBox(width: 4),
              Text('Surprise me', style: TextStyle(color: Pm.gold, fontSize: 12)),
            ]),
          ),
        ),
      ]),
      const SizedBox(height: 8),
      TextField(
        controller: _ctl, maxLines: 4, style: const TextStyle(color: Pm.cream),
        decoration: InputDecoration(
          hintText: 'A royal warrior standing in a golden palace...', hintStyle: const TextStyle(color: Pm.muted),
          filled: true, fillColor: Pm.card,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Pm.gold)),
        ),
      ),
      const SizedBox(height: 18),
      const Text('Style', style: TextStyle(color: Pm.cream, fontSize: 15, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: _styles.map((s) {
        final sel = s == _style;
        return GestureDetector(
          onTap: () => setState(() => _style = s),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              color: sel ? Pm.gold : Pm.card,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: sel ? Pm.gold : Pm.line),
            ),
            child: Text(s, style: TextStyle(color: sel ? Colors.black : Pm.cream, fontSize: 13, fontWeight: sel ? FontWeight.w700 : FontWeight.normal)),
          ),
        );
      }).toList()),
      const SizedBox(height: 10),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: Pm.line)),
        child: const Row(children: [
          Text('✨', style: TextStyle(fontSize: 16)),
          SizedBox(width: 8),
          Expanded(child: Text('No style mixing — your exact prompt will be used as-is', style: TextStyle(color: Pm.muted, fontSize: 12))),
        ]),
      ),
      const SizedBox(height: 18),
      const Text('Size', style: TextStyle(color: Pm.cream, fontSize: 15, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Row(children: _sizes.map((s) {
        final sel = s == _size;
        return Expanded(child: GestureDetector(
          onTap: () => setState(() => _size = s),
          child: Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: sel ? Pm.gold.withOpacity(0.15) : Pm.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: sel ? Pm.gold : Pm.line),
            ),
            child: Center(child: Text(s, style: TextStyle(color: sel ? Pm.gold : Pm.cream, fontSize: 12, fontWeight: sel ? FontWeight.w700 : FontWeight.normal))),
          ),
        ));
      }).toList()),
      const SizedBox(height: 20),
      // Generate button
      SizedBox(width: double.infinity, height: 54, child: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: Pm.gold, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        onPressed: _busy ? null : _generate,
        child: _busy
          ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
          : const Text('GENERATE IMAGE', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 1)),
      )),
      if (_err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_err!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center)),
      if (_img != null) ...[
        const SizedBox(height: 18),
        ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.memory(_img!, fit: BoxFit.cover)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(side: const BorderSide(color: Pm.gold), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)),
            onPressed: _download,
            icon: const Icon(Icons.download, color: Pm.gold),
            label: const Text('Download / Share', style: TextStyle(color: Pm.gold)),
          )),
          const SizedBox(width: 10),
          Expanded(child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Pm.gold, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)),
            onPressed: _generate,
            child: const Text('Regenerate', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w700)),
          )),
        ]),
      ],
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(10)),
        child: const Text('💡 Prompt + selected size will be sent to Pollinations. Watermark auto-cropped, Maharaja logo applied.', style: TextStyle(color: Pm.muted, fontSize: 12), textAlign: TextAlign.center),
      ),
      const SizedBox(height: 8),
      const Text('Powered by Pollinations.ai • Free tier', style: TextStyle(color: Pm.muted, fontSize: 11), textAlign: TextAlign.center),
      if (_banner != null) Container(margin: const EdgeInsets.only(top: 12), height: 50, child: AdWidget(ad: _banner!)),
      const SizedBox(height: 20),
    ]);
  }
}
