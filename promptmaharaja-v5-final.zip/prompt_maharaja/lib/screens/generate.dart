import 'dart:typed_data';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../theme.dart';
import '../data/store.dart';

class GenerateScreen extends StatefulWidget {
  const GenerateScreen({super.key});
  @override
  State<GenerateScreen> createState() => _GenerateScreenState();
}

class _GenerateScreenState extends State<GenerateScreen> {
  final _ctl = TextEditingController();
  String _style = 'No style';
  String _size = 'Square 1:1';
  bool _busy = false;
  Uint8List? _imgBytes;
  String? _err;

  final _styles = ['No style','Royal Portrait','Cinematic','Anime','Festival','Logo','Poster','Product','Artistic'];
  final _sizes = ['Square 1:1','Portrait 2:3','Landscape 3:2'];

  @override
  void dispose() { _ctl.dispose(); super.dispose(); }

  String _styleSuffix() {
    switch (_style) {
      case 'Royal Portrait': return ', royal Indian portrait style, ornate, majestic';
      case 'Cinematic': return ', cinematic film still, dramatic lighting';
      case 'Anime': return ', anime style, vibrant';
      case 'Festival': return ', festive Indian celebration style';
      case 'Logo': return ', professional logo design, vector style';
      case 'Poster': return ', movie poster style, dramatic';
      case 'Product': return ', professional product photography';
      case 'Artistic': return ', artistic masterpiece, detailed';
      default: return '';
    }
  }

  Future<void> _generate() async {
    final p = _ctl.text.trim();
    if (p.isEmpty) { setState(() => _err = 'Pehle prompt likho!'); return; }
    setState(() { _busy = true; _err = null; _imgBytes = null; });
    try {
      int w = 1024, h = 1024;
      if (_size == 'Portrait 2:3') { w = 768; h = 1152; }
      if (_size == 'Landscape 3:2') { w = 1152; h = 768; }
      final full = p + _styleSuffix();
      final url = 'https://image.pollinations.ai/prompt/${Uri.encodeComponent(full)}?width=$w&height=$h&nologo=true&seed=${DateTime.now().millisecondsSinceEpoch % 100000}';
      final resp = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 120));
      if (resp.statusCode == 200 && resp.bodyBytes.length > 10000) {
        setState(() { _imgBytes = resp.bodyBytes; });
      } else {
        setState(() => _err = 'Could not generate. Try again.');
      }
    } catch (e) {
      setState(() => _err = 'Could not generate. Check internet.');
    }
    setState(() => _busy = false);
  }

  Future<void> _download() async {
    if (_imgBytes == null) return;
    try {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/maharaja_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_imgBytes!);
      await Share.shareXFiles([XFile(file.path)], text: 'Created with Prompt Maharaja');
    } catch (e) {
      setState(() => _err = 'Download failed');
    }
  }

  void _surprise() {
    final all = Store.prompts;
    if (all.isEmpty) return;
    all.shuffle();
    _ctl.text = all.first.text;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SizedBox(height: 8),
        const Text('FREE AI STUDIO', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text('Generate Image', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        const Text('Describe your dream \u2014 the Maharaja paints it for free.', style: TextStyle(color: Pm.muted, fontSize: 14)),
        const SizedBox(height: 18),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Your prompt', style: TextStyle(color: Pm.cream, fontSize: 15, fontWeight: FontWeight.w600)),
            GestureDetector(
              onTap: _surprise,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: Pm.gold.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                child: const Text('Surprise me', style: TextStyle(color: Pm.gold, fontSize: 12)),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _ctl, maxLines: 4,
          style: const TextStyle(color: Pm.cream),
          decoration: InputDecoration(
            hintText: 'A royal warrior standing in a golden palace...',
            hintStyle: const TextStyle(color: Pm.muted),
            filled: true, fillColor: Pm.card,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Pm.line)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Pm.gold)),
          ),
        ),
        const SizedBox(height: 18),
        const Text('Style', style: TextStyle(color: Pm.cream, fontSize: 15, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: _styles.map((s) {
            final sel = s == _style;
            return GestureDetector(
              onTap: () => setState(() => _style = s),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                decoration: BoxDecoration(
                  color: sel ? Pm.gold : Pm.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: sel ? Pm.gold : Pm.line),
                ),
                child: Text(s, style: TextStyle(color: sel ? Colors.black : Pm.cream, fontSize: 13, fontWeight: sel ? FontWeight.w700 : FontWeight.normal)),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 18),
        const Text('Size', style: TextStyle(color: Pm.cream, fontSize: 15, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        Row(
          children: _sizes.map((s) {
            final sel = s == _size;
            return Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _size = s),
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: sel ? Pm.gold.withOpacity(0.15) : Pm.card,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: sel ? Pm.gold : Pm.line),
                  ),
                  child: Center(child: Text(s, style: TextStyle(color: sel ? Pm.gold : Pm.cream, fontSize: 12))),
                ),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 20),
        SizedBox(
          width: double.infinity, height: 54,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Pm.gold, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
            onPressed: _busy ? null : _generate,
            child: _busy
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                : const Text('GENERATE IMAGE', style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ),
        if (_err != null)
          Padding(padding: const EdgeInsets.only(top: 12), child: Text(_err!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center)),
        if (_imgBytes != null) ...[
          const SizedBox(height: 18),
          Stack(
            children: [
              ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.memory(_imgBytes!, fit: BoxFit.cover)),
              Positioned(
                bottom: 10, right: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.7), borderRadius: BorderRadius.circular(8)),
                  child: Row(children: [
                    Image.asset('assets/logo.png', width: 20, height: 20),
                    const SizedBox(width: 6),
                    const Text('Prompt Maharaja', style: TextStyle(color: Pm.gold, fontSize: 11, fontWeight: FontWeight.w700)),
                  ]),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(side: const BorderSide(color: Pm.gold), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)),
                onPressed: _download,
                icon: const Icon(Icons.download, color: Pm.gold),
                label: const Text('Download', style: TextStyle(color: Pm.gold, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Pm.gold, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), padding: const EdgeInsets.symmetric(vertical: 14)),
                onPressed: _generate,
                child: const Text('Regenerate', style: TextStyle(color: Colors.black, fontWeight: FontWeight.w700)),
              ),
            ),
          ]),
        ],
        const SizedBox(height: 20),
      ],
    );
  }
}
