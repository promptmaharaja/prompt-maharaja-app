
import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import 'category_detail.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});
  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  String _filter = 'All';

  @override
  Widget build(BuildContext context) {
    final icons = {
      'royal-portraits': Icons.workspace_premium,
      'cinematic': Icons.movie,
      'anime-world': Icons.auto_awesome,
      'festival-vibes': Icons.local_fire_department,
      'logo-lab': Icons.draw,
      'poster-house': Icons.image,
      'product-ads': Icons.shopping_bag,
      'art-styles': Icons.palette,
      'trending': Icons.trending_up,
    };
    final filters = ['All', ...Store.cats.map((c) => c.name)];
    List<PmCategory> cats = _filter == 'All'
        ? Store.cats
        : Store.cats.where((c) => c.name == _filter).toList();

    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      const Text('THE COLLECTION', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text('Categories', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      Text('${Store.prompts.length} royal prompts across ${Store.cats.length} categories', style: Pm.small),
      const SizedBox(height: 16),
      // Filter pills
      SizedBox(
        height: 40,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: filters.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final f = filters[i];
            final sel = f == _filter;
            return GestureDetector(
              onTap: () => setState(() => _filter = f),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  color: sel ? Pm.gold : Pm.card,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: sel ? Pm.gold : Pm.line),
                ),
                child: Text(f, style: TextStyle(color: sel ? Colors.black : Pm.cream, fontSize: 13, fontWeight: sel ? FontWeight.w700 : FontWeight.normal)),
              ),
            );
          },
        ),
      ),
      const SizedBox(height: 18),
      // Grid
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.95),
        itemCount: cats.length,
        itemBuilder: (_, i) {
          final cat = cats[i];
          final n = Store.prompts.where((p) => p.cat == cat.id).length;
          return GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CategoryDetailPage(cat: cat))),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(icons[cat.id] ?? Icons.auto_awesome, color: Pm.gold, size: 28),
                const SizedBox(height: 12),
                Text(cat.name, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w700), maxLines: 2),
                const SizedBox(height: 6),
                Text('$n prompts', style: const TextStyle(color: Pm.gold, fontSize: 12, fontWeight: FontWeight.w600)),
              ]),
            ),
          );
        },
      ),
      const SizedBox(height: 18),
      // AD placeholder
      Container(
        height: 50,
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(8), border: Border.all(color: Pm.line)),
        child: const Center(child: Text('AD - BANNER (320x50)', style: TextStyle(color: Pm.muted, fontSize: 11, letterSpacing: 1))),
      ),
      const SizedBox(height: 20),
    ]);
  }
}
