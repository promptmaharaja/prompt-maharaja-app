import 'package:flutter/material.dart';
import '../theme.dart';

class OpeningPage extends StatefulWidget {
  const OpeningPage({super.key});

  @override
  State<OpeningPage> createState() => _OpeningPageState();
}

class _OpeningPageState extends State<OpeningPage> with SingleTickerProviderStateMixin {
  late AnimationController _ctl;

  @override
  void initState() {
    super.initState();
    _ctl = AnimationController(vsync: this, duration: const Duration(seconds: 2));
    _ctl.forward();
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    });
  }

  @override
  void dispose() { _ctl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pm.bg,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 180, height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Pm.gold, width: 3),
                boxShadow: [
                  BoxShadow(color: Pm.gold.withOpacity(0.4), blurRadius: 40, spreadRadius: 10),
                ],
              ),
              child: ClipOval(
                child: Image.asset('assets/logo.png', fit: BoxFit.cover),
              ),
            ),
            const SizedBox(height: 40),
            Text('PROMPT', style: Pm.serif(48).copyWith(color: Pm.gold, fontWeight: FontWeight.w700, letterSpacing: 4)),
            Text('MAHARAJA', style: Pm.serif(48).copyWith(color: Pm.gold, fontWeight: FontWeight.w700, letterSpacing: 4)),
            const SizedBox(height: 16),
            const Text('AI PROMPTS COLLECTION', style: TextStyle(color: Pm.gold, fontSize: 14, letterSpacing: 6, fontWeight: FontWeight.w500)),
            const SizedBox(height: 12),
            Text('Royal prompts for majestic creations', style: Pm.serif(16).copyWith(color: Pm.cream.withOpacity(0.7), fontStyle: FontStyle.italic)),
            const SizedBox(height: 40),
            Container(
              width: 200, height: 4,
              decoration: BoxDecoration(color: Pm.line, borderRadius: BorderRadius.circular(2)),
              child: AnimatedBuilder(
                animation: _ctl,
                builder: (context, child) {
                  return FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: _ctl.value,
                    child: Container(decoration: BoxDecoration(color: Pm.gold, borderRadius: BorderRadius.circular(2))),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            const Text('OPENING TREASURY', style: TextStyle(color: Pm.muted, fontSize: 12, letterSpacing: 4)),
          ],
        ),
      ),
    );
  }
}
