import 'package:flutter/material.dart';
import '../theme.dart';
import '../shell.dart';

class OpeningPage extends StatefulWidget {
  const OpeningPage({super.key});
  @override
  State<OpeningPage> createState() => _OpeningPageState();
}

class _OpeningPageState extends State<OpeningPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const Shell()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Pm.bg,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/logo.png', width: 120, height: 120),
            const SizedBox(height: 24),
            Text('PROMPT MAHARAJA', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            const Text('Royal AI Prompts', style: TextStyle(color: Pm.gold, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
