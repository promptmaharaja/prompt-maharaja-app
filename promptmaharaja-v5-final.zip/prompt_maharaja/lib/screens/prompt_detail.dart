import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../theme.dart';
import '../data/prompts.dart';
import '../data/store.dart';
import '../favs.dart';

class PromptDetailPage extends StatefulWidget {
  final PmPrompt prompt;
  const PromptDetailPage({super.key, required this.prompt});
  @override
  State<PromptDetailPage> createState() => _PromptDetailPageState();
}

class _PromptDetailPageState extends State<PromptDetailPage> {
  bool _fav = false;
  @override
  void initState() { super.initState(); _fav = Favs.ids.contains(widget.prompt.id); }

  void _copy(String label, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$label copied!'), backgroundColor: Pm.gold, behavior: SnackBarBehavior.floating));
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.prompt;
    final catName = Store.catName(p.cat);
    return Scaffold(
      backgroundColor: Pm.bg,
      appBar: AppBar(
        backgroundColor: Pm.bg, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Pm.cream), onPressed: () => Navigator.pop(context)),
        title: Text(catName, style: Pm.serif(18)),
        actions: [
          IconButton(
            icon: Icon(_fav ? Icons.favorite : Icons.favorite_border, color: Pm.gold),
            onPressed: () { Favs.toggle(p.id); setState(() => _fav = !_fav); },
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined, color: Pm.cream),
            onPressed: () => Share.share('${p.title}\n\n${p.text}'),
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        // Title
        Text(p.title, style: Pm.serif(26).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(color: Pm.gold.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
          child: Text(catName.toUpperCase(), style: const TextStyle(color: Pm.gold, fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
        ),
        const SizedBox(height: 18),
        // Prompt box
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('PROMPT', style: TextStyle(color: Pm.gold, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
            const SizedBox(height: 10),
            Text(p.text, style: const TextStyle(color: Pm.cream, fontSize: 15, height: 1.6)),
          ]),
        ),
        const SizedBox(height: 14),
        // Copy button
        SizedBox(width: double.infinity, height: 52, child: ElevatedButton.icon(
          style: ElevatedButton.styleFrom(backgroundColor: Pm.gold, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          onPressed: () => _copy('Prompt', p.text),
          icon: const Icon(Icons.copy, color: Colors.black, size: 20),
          label: const Text('COPY PROMPT', style: TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.w700, letterSpacing: 1)),
        )),
        if (p.neg.isNotEmpty) ...[
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('NEGATIVE PROMPT', style: TextStyle(color: Pm.gold, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
              const SizedBox(height: 10),
              Text(p.neg, style: const TextStyle(color: Pm.muted, fontSize: 14, height: 1.5)),
            ]),
          ),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, height: 48, child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(side: const BorderSide(color: Pm.gold), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () => _copy('Negative prompt', p.neg),
            icon: const Icon(Icons.copy_outlined, color: Pm.gold, size: 18),
            label: const Text('COPY NEGATIVE', style: TextStyle(color: Pm.gold, fontSize: 14, fontWeight: FontWeight.w600)),
          )),
        ],
        const SizedBox(height: 14),
        // Char count
        Center(child: Text('${p.text.length} characters', style: Pm.small)),
        const SizedBox(height: 20),
      ]),
    );
  }
}
