import 'package:flutter/material.dart';
import '../theme.dart';
import '../data/store.dart';
import '../favs.dart';
import '../shell.dart';
import 'legal.dart';
import 'prompt_detail.dart';

class MoreScreen extends StatefulWidget {
  const MoreScreen({super.key});
  @override
  State<MoreScreen> createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> {
  @override
  void initState() { super.initState(); Favs.load().then((_) => setState(() {})); }

  Widget _legalTile(BuildContext context, String title, String body) {
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LegalPage(title: title, body: body))),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(title, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600)),
          const Icon(Icons.chevron_right, color: Pm.gold, size: 20),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      const SizedBox(height: 8),
      const Text('ROYAL TREASURY', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text('More', style: Pm.serif(28).copyWith(fontWeight: FontWeight.w700)),
      const SizedBox(height: 18),
      // Sign in card
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: Pm.line)),
        child: Column(children: [
          ClipRRect(borderRadius: BorderRadius.circular(30), child: Image.asset('assets/logo.png', width: 60, height: 60, fit: BoxFit.cover)),
          const SizedBox(height: 12),
          Text('Sign in to sync your royal treasury across devices.', style: Pm.serif(16).copyWith(fontWeight: FontWeight.w600), textAlign: TextAlign.center),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, height: 48, child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(side: BorderSide(color: Pm.line), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () {},
            icon: const Text('G', style: TextStyle(color: Pm.cream, fontSize: 18, fontWeight: FontWeight.w700)),
            label: const Text('Sign In with Google', style: TextStyle(color: Pm.cream, fontSize: 15)),
          )),
        ]),
      ),
      const SizedBox(height: 22),
      const Text('ABOUT', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _stat('29', 'Royal Prompts')),
        const SizedBox(width: 10),
        Expanded(child: _stat('9', 'Curated Categories')),
        const SizedBox(width: 10),
        Expanded(child: _stat('100%', 'Free Forever')),
      ]),
      const SizedBox(height: 22),
      const Text('HOW TO USE', style: TextStyle(color: Pm.gold, letterSpacing: 3, fontSize: 12, fontWeight: FontWeight.w700)),
      const SizedBox(height: 12),
      _step('1', 'Pick a prompt', 'Browse categories or search for a style you love.'),
      _step('2', 'Copy & paste', 'Tap copy, then paste into any AI image app.'),
      _step('3', 'Generate free', 'Or use our built-in AI studio to create images instantly.'),
      _step('4', 'Save favourites', 'Tap the heart to keep your best prompts handy.'),
      const SizedBox(height: 22),
      ...[
        ['Privacy Policy', LegalTexts.privacy],
        ['Terms of Use', LegalTexts.terms],
        ['Licence', LegalTexts.licence],
        ['Refund Policy', LegalTexts.refund],
        ['About Us', LegalTexts.about],
        ['Contact Us', LegalTexts.contact],
      ].map((l) => _legalTile(context, l[0] as String, l[1] as String)),
      const SizedBox(height: 16),
      const Center(child: Text('v1.0.0 • Made with ♥ for creators', style: TextStyle(color: Pm.muted, fontSize: 12))),
      const SizedBox(height: 24),
      // Admin panel section
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.gold.withOpacity(0.3))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('ADMIN PANEL (Owner Only)', style: TextStyle(color: Pm.gold, fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1)),
          const SizedBox(height: 8),
          const Text('Upload prompts via Firebase web admin:', style: TextStyle(color: Pm.muted, fontSize: 13)),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(color: Pm.bg, borderRadius: BorderRadius.circular(8), border: Border.all(color: Pm.line)),
            child: const Text('promptmaharaja.in/admin.html', style: TextStyle(color: Pm.gold, fontSize: 13)),
          ),
          const SizedBox(height: 8),
          const Text('Host the maharaja-admin.html file on your website to enable prompt uploads.', style: TextStyle(color: Pm.muted, fontSize: 12)),
        ]),
      ),
      const SizedBox(height: 20),
    ]);
  }

  Widget _stat(String n, String l) => Container(
    padding: const EdgeInsets.symmetric(vertical: 16),
    decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
    child: Column(children: [
      Text(n, style: Pm.serif(22).copyWith(color: Pm.gold, fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      Text(l, style: const TextStyle(color: Pm.muted, fontSize: 11), textAlign: TextAlign.center),
    ]),
  );

  Widget _step(String n, String t, String d) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Pm.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: Pm.line)),
    child: Row(children: [
      Container(
        width: 32, height: 32,
        decoration: const BoxDecoration(color: Pm.gold, shape: BoxShape.circle),
        child: Center(child: Text(n, style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w700))),
      ),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t, style: Pm.serif(16).copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(d, style: Pm.small),
      ])),
    ]),
  );
}
