// Generated from google-services.json (project: prompt-maharaja)
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError('Platform not supported');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAUSJTkF-RPDY3HeIOneEwsIYZVooF3sYM',
    appId: '1:798524289555:android:8ce298724e3d124a8f85e6',
    messagingSenderId: '798524289555',
    projectId: 'prompt-maharaja',
    storageBucket: 'prompt-maharaja.firebasestorage.app',
  );
}
