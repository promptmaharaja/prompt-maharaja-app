import 'package:shared_preferences/shared_preferences.dart';

class Favs {
  static const _k = 'fav_ids';
  static Set<String> ids = {};

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    ids = (p.getStringList(_k) ?? []).toSet();
  }

  static Future<Set<String>> get() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_k) ?? []).toSet();
  }

  static Future<void> toggle(String id) async {
    final p = await SharedPreferences.getInstance();
    final s = (p.getStringList(_k) ?? []).toSet();
    s.contains(id) ? s.remove(id) : s.add(id);
    await p.setStringList(_k, s.toList());
    ids = s;
  }

  static Future<bool> has(String id) async => (await get()).contains(id);
}
