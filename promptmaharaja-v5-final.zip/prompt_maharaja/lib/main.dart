import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'firebase_options.dart';
import 'data/store.dart';
import 'theme.dart';
import 'screens/splash.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    await Store.init();
  } catch (_) {
    // Firebase fail -> bundled 29 prompts chalenge
  }
  runApp(const MaharajaApp());
}

class MaharajaApp extends StatelessWidget {
  const MaharajaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Prompt Maharaja',
      debugShowCheckedModeBanner: false,
      theme: Pm.theme(),
      home: const NetGate(),
    );
  }
}

/// Offline me app nahi khulega - AdMob ke liye internet zaroori hai
class NetGate extends StatefulWidget {
  const NetGate({super.key});
  @override
  State<NetGate> createState() => _NetGateState();
}

class _NetGateState extends State<NetGate> {
  late final StreamSubscription<List<ConnectivityResult>> _sub;
  bool _online = true;
  bool _checked = false;

  @override
  void initState() {
    super.initState();
    _check();
    _sub = Connectivity().onConnectivityChanged.listen((r) {
      final on = r.any((e) => e != ConnectivityResult.none);
      if (mounted) setState(() => _online = on);
    });
  }

  Future<void> _check() async {
    final r = await Connectivity().checkConnectivity();
    if (mounted) {
      setState(() {
        _online = r.any((e) => e != ConnectivityResult.none);
        _checked = true;
      });
    }
  }

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_checked) {
      return const Scaffold(
        backgroundColor: Pm.bg,
        body: Center(child: CircularProgressIndicator(color: Pm.gold)),
      );
    }
    if (!_online) return _noNet();
    return const SplashScreen();
  }

  Widget _noNet() {
    return Scaffold(
      backgroundColor: Pm.bg,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 90, height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Pm.gold, width: 2),
                  ),
                  child: const Center(
                    child: Text('\u265B', style: TextStyle(fontSize: 44, color: Pm.gold)),
                  ),
                ),
                const SizedBox(height: 20),
                const Text('Internet Required',
                  style: TextStyle(color: Pm.gold, fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                const Text(
                  'Maharaja, internet connection on karo.\nAds aur latest prompts ke liye internet zaroori hai.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Pm.muted, fontSize: 15, height: 1.6)),
                const SizedBox(height: 28),
                ElevatedButton(
                  onPressed: _check,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Pm.gold, foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 14)),
                  child: const Text('RETRY', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
