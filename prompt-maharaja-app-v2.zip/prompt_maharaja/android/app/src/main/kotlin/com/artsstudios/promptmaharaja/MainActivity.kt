package com.artsstudios.promptmaharaja

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
