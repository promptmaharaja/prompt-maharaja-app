# Prompt Maharaja - Flutter App

PC ki zaroorat nahi - GitHub Actions APK banayega.

1. github.com > New repo: prompt-maharaja-app (Public)
2. Zip extract karo, files upload karo, Commit
3. Firebase > Settings > google-services.json fresh download > android/app/google-services.json replace
4. DEBUG_SHA1.txt ka SHA-1 Firebase > Project Settings > Add fingerprint me add karo
5. Actions > Build APK > Run workflow > APK download karo
