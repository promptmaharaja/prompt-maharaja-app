import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../config.dart';
class AdBanner extends StatefulWidget {
  const AdBanner({super.key});
  @override
  State<AdBanner> createState() => _AdBannerState();
}
class _AdBannerState extends State<AdBanner> {
  BannerAd? _ad;
  @override
  void initState() {
    super.initState();
    _ad = BannerAd(adUnitId: AppConfig.bannerAdId, size: AdSize.banner, request: const AdRequest(),
      listener: BannerAdListener(onAdFailedToLoad: (a, e) { a.dispose(); }))..load();
  }
  @override
  void dispose() { _ad?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_ad == null) return const SizedBox.shrink();
    return Container(alignment: Alignment.center, width: _ad!.size.width.toDouble(),
      height: _ad!.size.height.toDouble(), child: AdWidget(ad: _ad!));
  }
}
