import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../config.dart';
import 'legal_screen.dart';
class MoreScreen extends StatefulWidget {
  const MoreScreen({super.key});
  @override
  State<MoreScreen> createState() => _MoreScreenState();
}
class _MoreScreenState extends State<MoreScreen> {
  User? _user;
  @override
  void initState() { super.initState(); _user = FirebaseAuth.instance.currentUser; }
  Future<void> _signIn() async {
    try {
      final gUser = await GoogleSignIn().signIn();
      if (gUser == null) return;
      final gAuth = await gUser.authentication;
      final cred = GoogleAuthProvider.credential(accessToken: gAuth.accessToken, idToken: gAuth.idToken);
      final res = await FirebaseAuth.instance.signInWithCredential(cred);
      setState(() => _user = res.user);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login fail: ' + e.toString())));
    }
  }
  Future<void> _signOut() async {
    await GoogleSignIn().signOut();
    await FirebaseAuth.instance.signOut();
    setState(() => _user = null);
  }
  String _t(String k) {
    const m = {'privacy':'Privacy Policy','terms':'Terms of Use','licence':'Licence','refund':'Refund Policy','about':'About Us','contact':'Contact Us'};
    return m[k] ?? k;
  }
  @override
  Widget build(BuildContext context) {
    final pages = ['privacy','terms','licence','refund','about','contact'];
    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.gold.withOpacity(0.35))),
          child: _user == null
            ? Column(children: [
                const Text('Sign in karo - favorites sync honge', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 12),
                ElevatedButton.icon(onPressed: _signIn,
                  icon: const Icon(Icons.login, color: Colors.black),
                  label: const Text('Sign in with Google', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold)),
              ])
            : Row(children: [
                CircleAvatar(
                  backgroundImage: _user!.photoURL != null ? NetworkImage(_user!.photoURL!) : null,
                  backgroundColor: AppColors.gold,
                  child: _user!.photoURL == null ? Text((_user!.displayName ?? 'U')[0], style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)) : null),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(_user!.displayName ?? 'User', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  Text(_user!.email ?? '', style: const TextStyle(color: Colors.white60, fontSize: 12)),
                ])),
                TextButton(onPressed: _signOut, child: const Text('Logout', style: TextStyle(color: AppColors.gold))),
              ])),
        const SizedBox(height: 20),
        const Text('Legal', style: TextStyle(color: AppColors.gold, fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        for (final p in pages) Card(color: AppColors.card, margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            title: Text(_t(p), style: const TextStyle(color: Colors.white)),
            trailing: const Icon(Icons.arrow_forward_ios, color: AppColors.gold, size: 16),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LegalScreen(key2: p))))),
        const SizedBox(height: 16),
        const Center(child: Text('Built with heart in India\nArts Studios by SULTAN', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12))),
        const SizedBox(height: 8),
        const Center(child: Text('Version 1.0.0', style: TextStyle(color: Colors.white24, fontSize: 11))),
      ]));
  }
}
