import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../config.dart';
import 'prompt_detail_screen.dart';
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}
class _SearchScreenState extends State<SearchScreen> {
  String _q = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search Prompts')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(14),
          child: TextField(onChanged: (v) => setState(() => _q = v.toLowerCase().trim()),
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(hintText: 'Search title ya prompt...', hintStyle: const TextStyle(color: Colors.white38),
              prefixIcon: const Icon(Icons.search, color: AppColors.gold), filled: true, fillColor: AppColors.card,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none)))),
        Expanded(child: _q.isEmpty
          ? const Center(child: Text('Kuch likho search karne ke liye', style: TextStyle(color: Colors.white38)))
          : FutureBuilder<QuerySnapshot>(
              future: FirebaseFirestore.instance.collection('prompts').get(),
              builder: (c, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.gold));
                final docs = snap.data!.docs.where((d) {
                  final m = d.data() as Map<String, dynamic>;
                  return (m['title'] ?? '').toString().toLowerCase().contains(_q) || (m['prompt'] ?? '').toString().toLowerCase().contains(_q);
                }).toList();
                if (docs.isEmpty) return const Center(child: Text('Kuch nahi mila', style: TextStyle(color: Colors.white38)));
                return ListView.builder(padding: const EdgeInsets.symmetric(horizontal: 14), itemCount: docs.length,
                  itemBuilder: (c, i) {
                    final m = docs[i].data() as Map<String, dynamic>;
                    final title = (m['title'] ?? 'Untitled').toString();
                    return Card(color: AppColors.card, margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        subtitle: Text((m['cat'] ?? '').toString(), style: const TextStyle(color: AppColors.gold, fontSize: 12)),
                        trailing: const Icon(Icons.arrow_forward_ios, color: AppColors.gold, size: 16),
                        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => PromptDetailScreen(title: title, prompt: (m['prompt'] ?? '').toString(), neg: (m['neg'] ?? '').toString())))));
                  });
              })),
      ]));
  }
}
