import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import '../config.dart';
class GeneratorScreen extends StatefulWidget {
  const GeneratorScreen({super.key});
  @override
  State<GeneratorScreen> createState() => _GeneratorScreenState();
}
class _GeneratorScreenState extends State<GeneratorScreen> {
  final _ctrl = TextEditingController();
  String? _imgUrl;
  bool _loading = false;
  void _generate() async {
    final p = _ctrl.text.trim();
    if (p.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pehle prompt likho!'))); return; }
    setState(() { _loading = true; _imgUrl = null; });
    final seed = DateTime.now().millisecondsSinceEpoch % 999999;
    final url = 'https://image.pollinations.ai/prompt/' + Uri.encodeComponent(p) + '?width=1024&height=1024&seed=' + seed.toString() + '&nologo=false&model=flux';
    try {
      final r = await http.head(Uri.parse(url)).timeout(const Duration(seconds: 30));
      if (r.statusCode == 200) { setState(() => _imgUrl = url); }
      else { throw Exception('status ' + r.statusCode.toString()); }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Generate fail: ' + e.toString())));
    }
    setState(() => _loading = false);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Image Generator')),
      body: SingleChildScrollView(padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.gold.withOpacity(0.3))),
            child: const Text('Apna prompt likho, AI image banayega. Free plan me watermark logo ke saath.', style: TextStyle(color: Colors.white70, fontSize: 13))),
          const SizedBox(height: 14),
          TextField(controller: _ctrl, maxLines: 4, style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(hintText: 'e.g. Royal maharaja portrait, golden palace...', hintStyle: const TextStyle(color: Colors.white30),
              filled: true, fillColor: AppColors.card,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
          const SizedBox(height: 14),
          ElevatedButton.icon(onPressed: _loading ? null : _generate,
            icon: const Icon(Icons.auto_awesome, color: Colors.black),
            label: Text(_loading ? 'GENERATING...' : 'GENERATE IMAGE', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold, padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)))),
          const SizedBox(height: 16),
          if (_imgUrl != null) Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            ClipRRect(borderRadius: BorderRadius.circular(14),
              child: Image.network(_imgUrl!, fit: BoxFit.cover,
                loadingBuilder: (c, w, p) => p == null ? w : const SizedBox(height: 200, child: Center(child: CircularProgressIndicator(color: AppColors.gold))))),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: _generate,
                icon: const Icon(Icons.refresh, color: AppColors.gold), label: const Text('Regenerate', style: TextStyle(color: AppColors.gold)))),
              const SizedBox(width: 10),
              Expanded(child: ElevatedButton.icon(
                onPressed: () => Share.share('Maine Prompt Maharaja app se ye AI image banayi: ' + _imgUrl!),
                icon: const Icon(Icons.share, color: Colors.black),
                label: const Text('Share', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold))),
            ]),
          ]),
        ])));
  }
}
