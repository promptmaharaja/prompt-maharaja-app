import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../config.dart';
import 'prompt_detail_screen.dart';
class CategoryScreen extends StatelessWidget {
  final String cat;
  const CategoryScreen({super.key, required this.cat});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(cat)),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('prompts').where('cat', isEqualTo: cat).snapshots(),
        builder: (c, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: AppColors.gold));
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}', style: const TextStyle(color: Colors.white70)));
          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) return const Center(child: Text('Is category me abhi koi prompt nahi hai.\nAdmin panel se upload karo!', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)));
          return ListView.builder(padding: const EdgeInsets.all(14), itemCount: docs.length,
            itemBuilder: (c, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final title = (d['title'] ?? 'Untitled').toString();
              final prompt = (d['prompt'] ?? '').toString();
              return Card(color: AppColors.card,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: AppColors.gold.withOpacity(0.3))),
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(contentPadding: const EdgeInsets.all(14),
                  title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  subtitle: Text(prompt.length > 110 ? prompt.substring(0, 110) + '...' : prompt, style: const TextStyle(color: Colors.white60, fontSize: 13), maxLines: 3),
                  trailing: const Icon(Icons.arrow_forward_ios, color: AppColors.gold, size: 16),
                  onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => PromptDetailScreen(title: title, prompt: prompt, neg: (d['neg'] ?? '').toString())))));
            });
        }));
  }
}
