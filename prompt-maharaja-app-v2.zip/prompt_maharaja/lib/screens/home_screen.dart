import 'package:flutter/material.dart';
import '../config.dart';
import 'category_screen.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('\uD83D\uDC51 PROMPT MAHARAJA')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: double.infinity, padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.gold.withOpacity(0.4))),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('AI PROMPTS COLLECTION', style: TextStyle(color: AppColors.gold, fontSize: 11, letterSpacing: 3, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('Royal treasury of hand-crafted AI image prompts. Tap any style below.', style: TextStyle(color: Colors.white70, fontSize: 14, height: 1.5)),
            ])),
          const SizedBox(height: 20),
          const Text('Categories', style: TextStyle(color: AppColors.gold, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.6),
            itemCount: AppConfig.categories.length,
            itemBuilder: (c, i) {
              final cat = AppConfig.categories[i];
              return InkWell(
                onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => CategoryScreen(cat: cat))),
                child: Container(
                  decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.gold.withOpacity(0.35))),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(AppConfig.catIcons[cat], color: AppColors.gold, size: 30),
                    const SizedBox(height: 8),
                    Text(cat, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                  ])));
            }),
        ])));
  }
}
