import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../config.dart';
class PromptDetailScreen extends StatelessWidget {
  final String title, prompt, neg;
  const PromptDetailScreen({super.key, required this.title, required this.prompt, required this.neg});
  void _copy(BuildContext c, String t, String msg) {
    Clipboard.setData(ClipboardData(text: t));
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppColors.gold, duration: const Duration(seconds: 1)));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title, overflow: TextOverflow.ellipsis)),
      body: SingleChildScrollView(padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.gold.withOpacity(0.4))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('PROMPT', style: TextStyle(color: AppColors.gold, fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              SelectableText(prompt, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.6)),
            ])),
          const SizedBox(height: 14),
          ElevatedButton.icon(onPressed: () => _copy(context, prompt, 'Prompt copy ho gaya!'),
            icon: const Icon(Icons.copy, color: Colors.black),
            label: const Text('COPY PROMPT', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold, padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)))),
          if (neg.isNotEmpty) ...[
            const SizedBox(height: 14),
            Container(padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.gold.withOpacity(0.25))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('NEGATIVE PROMPT', style: TextStyle(color: AppColors.muted, fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                SelectableText(neg, style: const TextStyle(color: Colors.white70, fontSize: 14, height: 1.6)),
                const SizedBox(height: 10),
                OutlinedButton.icon(onPressed: () => _copy(context, neg, 'Negative prompt copy!'),
                  icon: const Icon(Icons.copy, size: 16, color: AppColors.gold),
                  label: const Text('Copy Negative', style: TextStyle(color: AppColors.gold))),
              ])),
          ],
        ])));
  }
}
