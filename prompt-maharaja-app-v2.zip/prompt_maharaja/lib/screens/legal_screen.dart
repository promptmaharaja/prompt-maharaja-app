import 'package:flutter/material.dart';
import '../config.dart';
import '../legal_content.dart';
class LegalScreen extends StatelessWidget {
  final String key2;
  const LegalScreen({super.key, required this.key2});
  @override
  Widget build(BuildContext context) {
    final secs = LegalContent.pages[key2] ?? [];
    return Scaffold(
      appBar: AppBar(title: Text(LegalContent.titles[key2] ?? key2)),
      body: ListView(padding: const EdgeInsets.all(16),
        children: [for (final s in secs) Container(margin: const EdgeInsets.only(bottom: 14), padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.gold.withOpacity(0.25))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s[0], style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            Text(s[1], style: const TextStyle(color: Colors.white70, fontSize: 14, height: 1.6)),
          ]))]));
  }
}
