class LegalContent {
  static const Map<String, String> titles = {'privacy':'Privacy Policy','terms':'Terms of Use','licence':'Licence','refund':'Refund Policy','about':'About Us','contact':'Contact Us'};
  static const Map<String, List<List<String>>> pages = {
    'privacy': [
      ['What we collect','We may collect device info, app usage stats, and advertising ID. Google sign-in gives us your name and email.'],
      ['How we use it','To improve the app, sync favorites, manage Premium, and show relevant ads.'],
      ['Advertising','Ads via Google AdMob. You can reset or limit ad personalization in device settings.'],
      ['Data storage','Data stored securely on Firebase (Google). We never sell your personal info.'],
      ['Contact','Privacy questions: hello@promptmaharaja.in']],
    'terms': [
      ['Free plan','Browse all categories and generate AI images. Free images carry the Prompt Maharaja watermark.'],
      ['Premium plan','Premium removes watermark and unlocks watermark-free downloads. Billed via Google Play.'],
      ['Fair use','Use prompts for your own creative projects. Do not resell the prompt library as a competing product.'],
      ['AI generation','Images are made by third-party AI services. Occasional failures may occur.'],
      ['Changes','Terms may update. Continued use means acceptance.']],
    'licence': [
      ['Prompt texts','All prompt texts are free for your personal and commercial creative projects.'],
      ['Free plan images','Free images include the watermark. Share anywhere with watermark intact.'],
      ['Premium images','Premium members get watermark-free downloads with full personal and commercial rights.'],
      ['Not allowed','Do not sell or republish the prompt collection itself as a competing product.']],
    'refund': [
      ['Payments','Premium purchases processed securely via Google Play. We never store card details.'],
      ['Refunds','Refunds follow Google Play refund policy. Request from Play order history.'],
      ['Help','Purchase issues? Email hello@promptmaharaja.in with your order ID.']],
    'about': [
      ['Our story','Prompt Maharaja is a royal treasury of hand-crafted AI image prompts, built with heart in India by Arts Studios by SULTAN.'],
      ['What we do','Every prompt is written like a director brief - rich, visual, ready to paste into your favourite AI art generator.'],
      ['Find us','Website: promptmaharaja.in. Email: hello@promptmaharaja.in']],
    'contact': [
      ['Email','hello@promptmaharaja.in - we read every message.'],
      ['WhatsApp channel','Follow Prompt Maharaja channel for daily viral AI photo prompts.'],
      ['Response time','Usually within 2 to 3 working days.']],
  };
}
