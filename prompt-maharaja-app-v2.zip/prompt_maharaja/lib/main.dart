import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const MaharajaApp());
}

class MaharajaApp extends StatelessWidget {
  const MaharajaApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Prompt Maharaja',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: Colors.black),
      home: const WebShell(),
    );
  }
}

class WebShell extends StatefulWidget {
  const WebShell({super.key});
  @override
  State<WebShell> createState() => _WebShellState();
}

class _WebShellState extends State<WebShell> {
  late final WebViewController _ctrl;
  BannerAd? _banner;
  bool _bannerReady = false;

  static const _hideAdsJs = "(function(){var s=document.createElement('style');s.innerHTML='.ad-slot{display:none!important}';document.head.appendChild(s);})();";

  @override
  void initState() {
    super.initState();
    _ctrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) => _ctrl.runJavaScript(_hideAdsJs),
      ))
      ..loadFlutterAsset('assets/demo/index.html');
    _banner = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111',
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _bannerReady = true),
        onAdFailedToLoad: (_, __) => setState(() => _bannerReady = false),
      ),
    )..load();
  }

  @override
  void dispose() { _banner?.dispose(); super.dispose(); }

  Future<bool> _onBack() async {
    if (await _ctrl.canGoBack()) { _ctrl.goBack(); return false; }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onBack,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            children: [
              Expanded(child: WebViewWidget(controller: _ctrl)),
              if (_bannerReady && _banner != null)
                SizedBox(width: _banner!.size.width.toDouble(), height: _banner!.size.height.toDouble(), child: AdWidget(ad: _banner!)),
            ],
          ),
        ),
      ),
    );
  }
}
