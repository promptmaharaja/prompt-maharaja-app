import 'package:flutter/material.dart';
class AppConfig {
  static const List<String> categories = ['AI Portraits','Anime','Cinematic','Festivals','Logos','Posters','Product Ads','Royal Portraits','Wedding'];
  static const Map<String, IconData> catIcons = {'AI Portraits':Icons.face,'Anime':Icons.auto_awesome,'Cinematic':Icons.movie,'Festivals':Icons.celebration,'Logos':Icons.branding_watermark,'Posters':Icons.image,'Product Ads':Icons.shopping_bag,'Royal Portraits':Icons.workspace_premium,'Wedding':Icons.favorite};
  static const String bannerAdId = 'ca-app-pub-3940256099942544/6300978111';
  static const String interstitialAdId = 'ca-app-pub-3940256099942544/1033173712';
}
class AppColors {
  static const Color bg = Color(0xFF0D0D0D);
  static const Color card = Color(0xFF1A1A1A);
  static const Color gold = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFF5D67B);
  static const Color muted = Color(0xFF9A8B5A);
}
